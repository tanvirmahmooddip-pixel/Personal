import React, { useState } from 'react';
import { 
  BookOpen, 
  Sparkles, 
  Heart, 
  Share2, 
  Tag, 
  Clock, 
  ChevronRight, 
  X, 
  Bot, 
  Search,
  CheckCircle2,
  Lock,
  ArrowRight,
  Plus,
  Send,
  HelpCircle,
  ShieldCheck,
  FileText
} from 'lucide-react';
import { TipPost, Language, UserRole } from '../types/family';
import { soundEffects } from '../utils/soundEffects';

interface FamilyBlogTipsProps {
  posts: TipPost[];
  language: Language;
  userRole: UserRole;
  onAskAiTopic: (topic: string) => void;
  soundEnabled: boolean;
  onAddPost?: (newPost: TipPost) => void;
}

export const FamilyBlogTips: React.FC<FamilyBlogTipsProps> = ({
  posts,
  language,
  userRole,
  onAskAiTopic,
  soundEnabled,
  onAddPost,
}) => {
  const isBn = language === 'bn';
  const [selectedPost, setSelectedPost] = useState<TipPost | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [likesMap, setLikesMap] = useState<Record<string, number>>(
    posts.reduce((acc, p) => ({ ...acc, [p.id]: p.likes }), {})
  );
  const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({});

  // Inline Helping AI question box
  const [inlineAiQuestion, setInlineAiQuestion] = useState('');
  const [inlineAiAnswer, setInlineAiAnswer] = useState<string | null>(null);
  const [isAskingAi, setIsAskingAi] = useState(false);

  // Add Post Modal State
  const [isAddPostModalOpen, setIsAddPostModalOpen] = useState(false);
  const [newTitleBn, setNewTitleBn] = useState('');
  const [newTitleEn, setNewTitleEn] = useState('');
  const [newCategory, setNewCategory] = useState<TipPost['category']>('legal_tips');
  const [newContentBn, setNewContentBn] = useState('');
  const [newContentEn, setNewContentEn] = useState('');
  const [newSummaryBn, setNewSummaryBn] = useState('');

  const canAddPost = userRole === 'Admin' || userRole === 'Editor';

  const handleLike = (postId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    soundEffects.playSuccess(soundEnabled);
    const hasLiked = likedPosts[postId];
    setLikedPosts((prev) => ({ ...prev, [postId]: !hasLiked }));
    setLikesMap((prev) => ({
      ...prev,
      [postId]: (prev[postId] || 0) + (hasLiked ? -1 : 1),
    }));
  };

  const categories = [
    { id: 'all', labelBn: 'সকল ব্লগ ও টিপস', labelEn: 'All Tips & Posts' },
    { id: 'land_sale', labelBn: 'জমি বিক্রি ও নামজারি', labelEn: 'Land Sale & Mutation' },
    { id: 'legal_tips', labelBn: 'আইনি সহায়তা ও শুনানি', labelEn: 'Legal Hearing Tips' },
    { id: 'vault_security', labelBn: 'ভল্ট এনক্রিপশন ও সাইবার', labelEn: 'Vault Security' },
    { id: 'inheritance', labelBn: 'উত্তরাধিকার ফারায়েয', labelEn: 'Inheritance Rules' },
  ];

  const filteredPosts = posts.filter((p) => {
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch = 
      !q || 
      p.titleBn.toLowerCase().includes(q) || 
      p.titleEn.toLowerCase().includes(q) ||
      p.summaryBn.toLowerCase().includes(q) ||
      p.summaryEn.toLowerCase().includes(q) ||
      p.tags.some(t => t.toLowerCase().includes(q));

    return matchesCategory && matchesSearch;
  });

  // Handle Inline Helping AI Query
  const handleAskInlineAi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inlineAiQuestion.trim() || isAskingAi) return;

    soundEffects.playClick(soundEnabled);
    setIsAskingAi(true);
    setInlineAiAnswer(null);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `আপনি মারুফের পরিবারের আইনি এআই সহায়ক। ব্যবহারকারীর এই ব্লগ/আইনি প্রশ্নের একটি সুস্পষ্ট ও তথ্যবহুল উত্তর দিন: "${inlineAiQuestion}". অনুগ্রহ করে উত্তরটি সহজ বাংলায় ও সংক্ষেপে দিন।`,
        }),
      });
      const data = await res.json();
      setInlineAiAnswer(data.reply || data.fallback || 'উত্তর প্রদানে সমস্যা হয়েছে।');
      soundEffects.playSuccess(soundEnabled);
    } catch (err) {
      setInlineAiAnswer(isBn ? 'দুঃখিত, এআই সার্ভারের সাথে সংযোগে সাময়িক সমস্যা হয়েছে।' : 'Failed to reach AI helper.');
    } finally {
      setIsAskingAi(false);
    }
  };

  // Submit New Post
  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitleBn.trim() || !newContentBn.trim()) return;

    const createdPost: TipPost = {
      id: `tip-${Date.now()}`,
      titleBn: newTitleBn,
      titleEn: newTitleEn || newTitleBn,
      category: newCategory,
      summaryBn: newSummaryBn || newContentBn.slice(0, 100) + '...',
      summaryEn: newContentEn ? newContentEn.slice(0, 100) + '...' : 'New practical tip published.',
      contentBn: newContentBn,
      contentEn: newContentEn || newContentBn,
      readTime: '৩ মিনিট পাঠ',
      publishedDate: new Date().toISOString().split('T')[0],
      likes: 1,
      tags: ['পারিবারিক টিপস', 'নতুন পোস্ট', 'আইন'],
    };

    if (onAddPost) {
      onAddPost(createdPost);
    }
    soundEffects.playSuccess(soundEnabled);
    setIsAddPostModalOpen(false);
    setNewTitleBn('');
    setNewTitleEn('');
    setNewContentBn('');
    setNewContentEn('');
    setNewSummaryBn('');
  };

  return (
    <div className="space-y-6">
      
      {/* Blog Hero Banner with Visual Glow */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 border border-emerald-500/30 p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-semibold">
              <BookOpen className="w-3.5 h-3.5" />
              <span>{isBn ? 'পারিবারিক আইনি জ্ঞানকোষ ও ফিচার ব্লগ' : 'Family Legal Knowledge Hub & Blog'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {isBn ? 'আইনি পরামর্শ, জমি বিক্রির কৌশল ও নিরাপত্তা টিপস' : 'Legal Advice, Land Sale Tricks & Security Tips'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {isBn
                ? 'ওয়ারিশ জমি বিক্রির নিয়ম, বণ্টননামা দলিলের গুরুত্ব, এসি ল্যান্ড অফিসের শুনানি প্রস্তুতি এবং ডিজিটাল ভল্টের এনক্রিপশন নিয়ে দরকারি দিকনির্দেশনা।'
                : 'Practical statutory guides for conveying inherited land, avoiding litigation, and maximizing digital vault confidentiality.'}
            </p>
          </div>

          {canAddPost && (
            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setIsAddPostModalOpen(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition shadow-lg shadow-emerald-950/50 flex items-center gap-2 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>{isBn ? 'নতুন পোস্ট / টিপস লিখুন' : 'Write Tip Post'}</span>
            </button>
          )}
        </div>

        {/* Categories Bar & Search */}
        <div className="mt-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs scrollbar-none">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  soundEffects.playClick(soundEnabled);
                  setSelectedCategory(c.id);
                }}
                className={`px-3.5 py-1.5 rounded-xl font-semibold whitespace-nowrap transition ${
                  selectedCategory === c.id
                    ? 'bg-emerald-600 text-white shadow'
                    : 'bg-slate-850 text-slate-400 hover:text-white border border-slate-700/60'
                }`}
              >
                {isBn ? c.labelBn : c.labelEn}
              </button>
            ))}
          </div>

          <div className="relative min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isBn ? 'ব্লগ ও টিপস খুঁজুন...' : 'Search articles...'}
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* Interactive Helping AI Quick Inquiry Bar */}
      <div className="rounded-2xl bg-slate-900/90 border border-emerald-500/30 p-4 sm:p-5 shadow-lg">
        <div className="flex items-center gap-2 mb-2 text-xs font-bold text-emerald-400">
          <Bot className="w-4 h-4" />
          <span>{isBn ? 'হেল্পিং এআই: ব্লগ ও আইনি বিষয়ে সরাসরি জিজ্ঞাসা করুন' : 'Helping AI: Ask any Legal or Land Question Directly'}</span>
        </div>
        
        <form onSubmit={handleAskInlineAi} className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={inlineAiQuestion}
            onChange={(e) => setInlineAiQuestion(e.target.value)}
            placeholder={isBn ? 'যেমন: বণ্টননামা দলিল ছাড়া কি ভাই নিজের অংশ রেজিস্ট্রি দিতে পারবে?' : 'e.g., Can an heir sell inherited land without partition deed?'}
            className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
          <button
            type="submit"
            disabled={isAskingAi || !inlineAiQuestion.trim()}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition flex items-center justify-center gap-2 shrink-0"
          >
            {isAskingAi ? (
              <span className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            ) : (
              <Send className="w-3.5 h-3.5" />
            )}
            <span>{isBn ? 'উত্তর দিন' : 'Ask AI'}</span>
          </button>
        </form>

        {inlineAiAnswer && (
          <div className="mt-3 p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-200 leading-relaxed space-y-1">
            <div className="flex items-center justify-between font-bold text-white">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{isBn ? 'এআই আইনি বিশ্লেষণ:' : 'AI Legal Advice:'}</span>
              </span>
              <button 
                onClick={() => setInlineAiAnswer(null)} 
                className="text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="whitespace-pre-wrap">{inlineAiAnswer}</p>
          </div>
        )}
      </div>

      {/* Posts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredPosts.map((post) => {
          const currentLikes = likesMap[post.id] || post.likes;
          const isLiked = likedPosts[post.id];

          return (
            <div
              key={post.id}
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setSelectedPost(post);
              }}
              className="p-6 rounded-3xl bg-slate-850 border border-slate-700/60 hover:border-emerald-500/50 shadow-lg hover:shadow-emerald-950/20 transition-all duration-300 cursor-pointer flex flex-col justify-between group"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1 font-mono text-emerald-400">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{post.readTime}</span>
                  </span>
                  <span>{post.publishedDate}</span>
                </div>

                <h3 className="font-extrabold text-base text-white group-hover:text-emerald-300 transition-colors leading-snug">
                  {isBn ? post.titleBn : post.titleEn}
                </h3>

                <p className="text-xs text-slate-300 leading-relaxed line-clamp-3">
                  {isBn ? post.summaryBn : post.summaryEn}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {post.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] px-2 py-0.5 rounded-md bg-slate-900 text-slate-400 border border-slate-750"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Card Footer */}
              <div className="mt-5 pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs">
                <button
                  onClick={(e) => handleLike(post.id, e)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-xl transition ${
                    isLiked 
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' 
                      : 'bg-slate-900 text-slate-400 hover:text-rose-300 border border-slate-750'
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-rose-400 text-rose-400' : ''}`} />
                  <span>{currentLikes}</span>
                </button>

                <div className="flex items-center gap-1 text-emerald-400 font-semibold group-hover:translate-x-1 transition-transform">
                  <span>{isBn ? 'সম্পূর্ণ পড়ুন' : 'Read Article'}</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Article Detail Modal */}
      {selectedPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-3xl rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-6 sm:p-8 space-y-5 my-auto max-h-[85vh] overflow-y-auto">
            <button
              onClick={() => setSelectedPost(null)}
              className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="space-y-2 border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="text-emerald-400 font-bold">{selectedPost.readTime}</span>
                <span>•</span>
                <span>{selectedPost.publishedDate}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white leading-tight">
                {isBn ? selectedPost.titleBn : selectedPost.titleEn}
              </h2>
            </div>

            {/* Markdown content */}
            <div className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap font-sans bg-slate-950/60 p-5 rounded-2xl border border-slate-800">
              {isBn ? selectedPost.contentBn : selectedPost.contentEn}
            </div>

            {/* Quick Ask AI button on this topic */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 to-indigo-950/60 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-emerald-300">
                <Bot className="w-5 h-5 shrink-0" />
                <span>{isBn ? 'এই বিষয়ের উপর আরও নির্দিষ্ট আইনি প্রশ্ন আছে?' : 'Have specific legal questions regarding this topic?'}</span>
              </div>
              <button
                onClick={() => {
                  setSelectedPost(null);
                  onAskAiTopic(isBn ? selectedPost.titleBn : selectedPost.titleEn);
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold flex items-center gap-1.5 transition"
              >
                <span>{isBn ? 'এআই সহায়ককে জিজ্ঞাসা করুন' : 'Ask AI Assistant'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Tip Post Modal */}
      {isAddPostModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="relative w-full max-w-xl rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4">
            <button
              onClick={() => setIsAddPostModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-400" />
              <span>{isBn ? 'নতুন আইনি টিপস / ব্লগ পোস্ট লিখুন' : 'Create New Legal Tip / Post'}</span>
            </h3>

            <form onSubmit={handleCreatePost} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  {isBn ? 'শিরোনাম (বাংলা)' : 'Title (Bangla)'}
                </label>
                <input
                  type="text"
                  required
                  value={newTitleBn}
                  onChange={(e) => setNewTitleBn(e.target.value)}
                  placeholder="যেমন: বণ্টননামা দলিলের সঠিক নিয়মাবলী..."
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  {isBn ? 'ক্যাটাগরি' : 'Category'}
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs"
                >
                  <option value="land_sale">{isBn ? 'জমি বিক্রি ও নামজারি' : 'Land Sale & Mutation'}</option>
                  <option value="legal_tips">{isBn ? 'আইনি সহায়তা ও শুনানি' : 'Legal Hearing Tips'}</option>
                  <option value="vault_security">{isBn ? 'ভল্ট এনক্রিপশন ও সাইবার' : 'Vault Security'}</option>
                  <option value="inheritance">{isBn ? 'উত্তরাধিকার ফারায়েয' : 'Inheritance Rules'}</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  {isBn ? 'সংক্ষিপ্ত সারসংক্ষেপ' : 'Summary'}
                </label>
                <textarea
                  rows={2}
                  value={newSummaryBn}
                  onChange={(e) => setNewSummaryBn(e.target.value)}
                  placeholder="সংক্ষেপে মূল বিষয়বস্তু..."
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  {isBn ? 'মূল বিবরণ ও পরামর্শ' : 'Full Content / Advice'}
                </label>
                <textarea
                  rows={5}
                  required
                  value={newContentBn}
                  onChange={(e) => setNewContentBn(e.target.value)}
                  placeholder="পয়েন্ট আকারে মূল পরামর্শ লিখুন..."
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddPostModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  {isBn ? 'প্রকাশ করুন' : 'Publish'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
