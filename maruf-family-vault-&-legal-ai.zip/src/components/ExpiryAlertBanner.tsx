import React, { useState } from 'react';
import { AlertTriangle, Clock, X, ChevronRight, ShieldAlert } from 'lucide-react';
import { VaultDocument, Language } from '../types/family';

interface ExpiryAlertBannerProps {
  documents: VaultDocument[];
  language: Language;
  onOpenVault: () => void;
}

export const ExpiryAlertBanner: React.FC<ExpiryAlertBannerProps> = ({
  documents,
  language,
  onOpenVault,
}) => {
  const isBn = language === 'bn';
  const [dismissed, setDismissed] = useState(false);

  // Check documents with <= 30 days
  const now = new Date().getTime();
  const expiringDocs = documents
    .map((doc) => {
      if (!doc.expiryDate) return null;
      const exp = new Date(doc.expiryDate).getTime();
      const daysLeft = Math.ceil((exp - now) / (1000 * 60 * 60 * 24));
      return { ...doc, daysLeft };
    })
    .filter((d): d is VaultDocument & { daysLeft: number } => d !== null && d.daysLeft <= 30 && d.daysLeft >= 0)
    .sort((a, b) => a.daysLeft - b.daysLeft);

  if (dismissed || expiringDocs.length === 0) return null;

  const mostUrgent = expiringDocs[0];
  const isCritical = mostUrgent.daysLeft <= 7;

  return (
    <div
      className={`border-b px-4 py-2.5 transition-all text-xs font-medium flex items-center justify-between gap-3 ${
        isCritical
          ? 'bg-rose-950/90 text-rose-200 border-rose-800'
          : 'bg-amber-950/90 text-amber-200 border-amber-800'
      }`}
    >
      <div className="flex items-center gap-2.5 overflow-hidden">
        <span className={`p-1 rounded-lg shrink-0 ${isCritical ? 'bg-rose-600 text-white animate-pulse' : 'bg-amber-600 text-white'}`}>
          <AlertTriangle className="w-3.5 h-3.5" />
        </span>
        <div className="truncate">
          <span className="font-bold">
            {isCritical 
              ? (isBn ? '🚨 জরুরি মেয়াদ উত্তীর্ণের অ্যালার্ট:' : '🚨 Urgent Expiry Alert:') 
              : (isBn ? '⚠️ আসন্ন মেয়াদ সতর্কতা:' : '⚠️ Upcoming Expiry Warning:')}
          </span>{' '}
          <span className="text-white font-semibold">
            "{isBn ? mostUrgent.titleBn : mostUrgent.titleEn}"
          </span>{' '}
          {isBn
            ? `এর মেয়াদ আর মাত্র ${mostUrgent.daysLeft} দিন বাকি রয়েছে!`
            : `expires in only ${mostUrgent.daysLeft} days!`}
          {expiringDocs.length > 1 && (
            <span className="ml-1 opacity-80">
              {isBn 
                ? `(আরও ${expiringDocs.length - 1}টি দলিলের মেয়াদ শীঘ্রই শেষ হবে)` 
                : `(+${expiringDocs.length - 1} more documents expiring)`}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onOpenVault}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition shadow ${
            isCritical
              ? 'bg-rose-600 hover:bg-rose-500 text-white'
              : 'bg-amber-600 hover:bg-amber-500 text-slate-950'
          }`}
        >
          <span>{isBn ? 'ভল্ট দেখুন' : 'View Vault'}</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={() => setDismissed(true)}
          className="p-1 hover:opacity-100 opacity-70 transition"
          title={isBn ? 'বন্ধ করুন' : 'Dismiss'}
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
