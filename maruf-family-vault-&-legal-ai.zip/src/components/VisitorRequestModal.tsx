import React, { useState } from 'react';
import { X, Send, FileUp, Sparkles, CheckCircle2 } from 'lucide-react';
import { Language, VisitorRequest } from '../types/family';

interface VisitorRequestModalProps {
  language: Language;
  onClose: () => void;
  onSubmitRequest: (req: VisitorRequest) => void;
}

export const VisitorRequestModal: React.FC<VisitorRequestModalProps> = ({
  language,
  onClose,
  onSubmitRequest,
}) => {
  const isBn = language === 'bn';
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [relationClaim, setRelationClaim] = useState('');
  const [requestType, setRequestType] = useState<'document_upload' | 'info_update' | 'contact_query'>('info_update');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !title) return;

    const newReq: VisitorRequest = {
      id: `req-${Date.now()}`,
      submitterName: name,
      submitterPhone: phone || '+880 17...',
      submitterEmail: email,
      relationClaimBn: relationClaim || 'পারিবারিক শুভাকাঙ্ক্ষী',
      relationClaimEn: relationClaim || 'Family Relative',
      requestType,
      title,
      description,
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'pending',
    };

    onSubmitRequest(newReq);
    setIsSuccess(true);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700/80 p-6 sm:p-8 space-y-4 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>

        {isSuccess ? (
          <div className="py-8 text-center space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h3 className="text-base font-bold text-white">
              {isBn ? 'আপনার আবেদন সফলভাবে জমা হয়েছে!' : 'Request Submitted Successfully!'}
            </h3>
            <p className="text-xs text-slate-300">
              {isBn 
                ? 'মারুফ ভাই অ্যাডমিন পোর্টাল থেকে যাচাই করে অনুমোদন দিলেই তা ডিরেক্টরিতে দৃশ্যমান হবে।' 
                : 'Maruf will review and publish your submission in the family vault.'}
            </p>
          </div>
        ) : (
          <>
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <FileUp className="w-5 h-5 text-emerald-400" />
                <span>{isBn ? 'তথ্য পরিবর্তন বা দলিল জমার অনুরোধ' : 'Submit Information or Document'}</span>
              </h3>
              <p className="text-xs text-slate-400">
                {isBn 
                  ? 'পরিবারের সদস্য বা আত্মীয়গণ তাঁদের তথ্য বা দলিলের কপি মারুফের অনুমোদনের জন্য জমা দিতে পারেন।' 
                  : 'Family members and relatives can submit records for Maruf’s approval.'}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'আপনার নাম' : 'Your Name'}
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={isBn ? 'যেমন: ওমর ফারুক / পান্না' : 'e.g. Omar Faruque'}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'মোবাইল নম্বর' : 'Phone'}
                  </label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+880 1..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'পরিবারে আপনার পরিচয় বা সম্পর্ক' : 'Your Relationship Claim'}
                </label>
                <input
                  type="text"
                  value={relationClaim}
                  onChange={(e) => setRelationClaim(e.target.value)}
                  placeholder={isBn ? 'যেমন: বড় ভাই / মেজো ভাই / ভাবি / ভাগ্নে' : 'e.g. Brother, Sister-in-law'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'অনুরোধের ধরন' : 'Request Type'}
                  </label>
                  <select
                    value={requestType}
                    onChange={(e: any) => setRequestType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="info_update">{isBn ? 'নাম বা তথ্যের সংশোধন' : 'Info Update'}</option>
                    <option value="document_upload">{isBn ? 'নতুন দলিল / সনদ জমা' : 'Document Submission'}</option>
                    <option value="contact_query">{isBn ? 'যোগাযোগ বা প্রশ্ন' : 'General Query'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'বিষয় / শিরোনাম' : 'Subject'}
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={isBn ? 'যেমন: মেয়ের সঠিক নাম সংযোজন' : 'e.g. Add daughter name'}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'বিস্তারিত বিবরণ' : 'Description / Details'}
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={isBn ? 'আপনার বিস্তারিত অনুরোধ বা প্রস্তাব এখানে লিখুন...' : 'Write your details here...'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow flex items-center gap-1.5"
                >
                  <span>{isBn ? 'অনুরোধ জমা দিন' : 'Submit'}</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
