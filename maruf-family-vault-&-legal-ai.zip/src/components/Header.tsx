import React, { useState } from 'react';
import { 
  ShieldCheck, 
  FolderLock, 
  Calculator, 
  FileText, 
  Bot, 
  UserCheck, 
  Lock, 
  Unlock, 
  Languages, 
  Sun, 
  Moon, 
  Users, 
  ChevronDown,
  ShieldAlert,
  User, 
  CheckCircle2, 
  SlidersHorizontal,
  BookOpen,
  Music,
  Volume2,
  VolumeX,
  LogOut,
  Sparkles
} from 'lucide-react';
import { Language, AdminSettings, UserRole, FamilyMember } from '../types/family';
import { soundEffects } from '../utils/soundEffects';

interface HeaderProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  language: Language;
  onToggleLanguage: () => void;
  isAdminLoggedIn: boolean;
  currentUser: FamilyMember;
  activeRole: UserRole;
  allMembers: FamilyMember[];
  onSwitchUser: (memberId: string) => void;
  onOpenLoginModal: () => void;
  onLogoutAdmin: () => void;
  onLockVault: () => void;
  pendingRequestsCount: number;
  expiringDocsCount: number;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  settings: AdminSettings;
  soundEnabled: boolean;
  onToggleSound: () => void;
  isMusicOn: boolean;
  onToggleMusic: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  language,
  onToggleLanguage,
  isAdminLoggedIn,
  currentUser,
  activeRole,
  allMembers,
  onSwitchUser,
  onOpenLoginModal,
  onLogoutAdmin,
  onLockVault,
  pendingRequestsCount,
  expiringDocsCount,
  darkMode,
  onToggleDarkMode,
  soundEnabled,
  onToggleSound,
  isMusicOn,
  onToggleMusic,
}) => {
  const isBn = language === 'bn';
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);

  const roleBadgeStyles: Record<UserRole, { bg: string; text: string; border: string }> = {
    Admin: { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/40' },
    Editor: { bg: 'bg-blue-500/20', text: 'text-blue-300', border: 'border-blue-500/40' },
    Viewer: { bg: 'bg-slate-700/80', text: 'text-slate-300', border: 'border-slate-600' },
  };

  const navItems = [
    { id: 'directory', labelBn: 'পরিবার ডিরেক্টরি', labelEn: 'Family Tree', icon: Users },
    { id: 'vault', labelBn: 'ডকুমেন্ট ভল্ট', labelEn: 'Document Vault', icon: FolderLock, badge: expiringDocsCount },
    { id: 'inheritance', labelBn: 'উত্তরাধিকার ক্যালকুলেটর', labelEn: 'Inheritance Calc', icon: Calculator },
    { id: 'enamjari', labelBn: 'ই-নামজারি ও জমি বিক্রি', labelEn: 'e-Namjari Guide', icon: FileText },
    { id: 'ai', labelBn: 'এআই আইনি সহকারী', labelEn: 'Legal AI', icon: Bot },
    { id: 'tips', labelBn: 'ব্লগ ও আইনি টিপস', labelEn: 'Blog & Tips', icon: BookOpen },
    { id: 'admin', labelBn: 'অ্যাডমিন প্যানেল', labelEn: 'Admin Panel', icon: UserCheck, badge: isAdminLoggedIn ? pendingRequestsCount : 0, isSpecial: true },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-slate-700/60 bg-slate-900/95 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-2">
          
          {/* Logo & Branding */}
          <div 
            onClick={() => {
              soundEffects.playClick(soundEnabled);
              onSelectTab('directory');
            }}
            className="flex items-center gap-3 cursor-pointer group shrink-0"
          >
            <div className="relative p-2.5 rounded-2xl bg-gradient-to-tr from-emerald-700 via-emerald-600 to-teal-500 text-white shadow-lg shadow-emerald-900/30 group-hover:scale-105 transition-transform">
              <ShieldCheck className="w-6 h-6 sm:w-7 sm:h-7" />
              {expiringDocsCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-4 w-4 bg-amber-500 text-[10px] text-slate-950 font-bold items-center justify-center">
                    {expiringDocsCount}
                  </span>
                </span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base sm:text-xl tracking-tight text-white group-hover:text-emerald-400 transition-colors">
                  {isBn ? 'মারুফের পরিবার' : "Maruf's Family"}
                </span>
                <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  {isBn ? 'ডিজিটাল ভল্ট' : 'Vault & Legal'}
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                {isBn 
                  ? 'পারিবারিক পোর্টফোলিও, ফারায়েয বণ্টন ও এআই আইনি সহায়ক' 
                  : 'Family Portfolio, Inheritance Calculator & AI Legal Assistant'}
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden xl:flex items-center gap-1 bg-slate-800/80 p-1.5 rounded-2xl border border-slate-700/60 shadow-inner">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    soundEffects.playClick(soundEnabled);
                    onSelectTab(item.id);
                  }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all relative ${
                    isActive
                      ? item.isSpecial
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/40'
                        : 'bg-emerald-600 text-white shadow-md shadow-emerald-900/40'
                      : item.isSpecial
                        ? 'text-indigo-300 hover:text-white hover:bg-slate-700/50'
                        : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{isBn ? item.labelBn : item.labelEn}</span>
                  {item.badge && item.badge > 0 ? (
                    <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                      item.isSpecial ? 'bg-rose-500 text-white' : 'bg-amber-500 text-slate-950'
                    }`}>
                      {item.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2">

            {/* Ambient Music Synthesizer Toggle */}
            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                onToggleMusic();
              }}
              title={isBn ? 'শান্ত আবহ সঙ্গীত (Lo-Fi Ambient Chords)' : 'Ambient Background Music'}
              className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all shadow-sm ${
                isMusicOn 
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-emerald-950/40' 
                  : 'bg-slate-800 text-slate-400 border-slate-700/70 hover:text-slate-200'
              }`}
            >
              <Music className={`w-3.5 h-3.5 ${isMusicOn ? 'text-emerald-400 animate-bounce' : ''}`} />
              <span className="hidden md:inline">
                {isBn ? (isMusicOn ? 'সঙ্গীত চলছে' : 'সঙ্গীত') : (isMusicOn ? 'Music ON' : 'Music')}
              </span>
              {isMusicOn && (
                <span className="flex gap-0.5 items-end h-2.5">
                  <span className="w-0.5 h-1.5 bg-emerald-400 animate-pulse" />
                  <span className="w-0.5 h-2.5 bg-emerald-400 animate-pulse delay-75" />
                  <span className="w-0.5 h-1 bg-emerald-400 animate-pulse delay-150" />
                </span>
              )}
            </button>

            {/* Sound FX Toggle */}
            <button
              onClick={() => {
                onToggleSound();
                soundEffects.playClick(!soundEnabled);
              }}
              title={isBn ? 'সাউন্ড ইফেক্টস (UI Chimes)' : 'UI Sound Effects'}
              className={`p-2 rounded-xl border text-xs transition ${
                soundEnabled 
                  ? 'bg-slate-800 text-teal-300 border-teal-500/40' 
                  : 'bg-slate-900 text-slate-500 border-slate-800'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* RBAC Active User & Role Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => {
                  soundEffects.playClick(soundEnabled);
                  setIsRoleDropdownOpen(!isRoleDropdownOpen);
                }}
                className={`flex items-center gap-2 px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs font-semibold transition shadow-sm ${roleBadgeStyles[activeRole].bg} ${roleBadgeStyles[activeRole].border}`}
                title={isBn ? 'ভূমিকা ও ইউজার পরিবর্তন করুন' : 'Switch RBAC User Role'}
              >
                <div className="w-5 h-5 rounded-lg bg-slate-800 text-white flex items-center justify-center font-bold text-[10px]">
                  {currentUser.nameBn ? currentUser.nameBn.slice(0, 1) : 'M'}
                </div>
                <div className="text-left hidden sm:block">
                  <span className="text-[10px] text-slate-400 block leading-tight">
                    {isBn ? 'বর্তমান ভূমিকা' : 'Active Role'}
                  </span>
                  <span className={`font-bold leading-tight ${roleBadgeStyles[activeRole].text}`}>
                    {isBn ? currentUser.nameBn.split(' ')[0] : currentUser.nameEn.split(' ')[0]} ({activeRole})
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {/* Role Dropdown Menu */}
              {isRoleDropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-slate-900 border border-slate-700/90 shadow-2xl p-2 z-50 text-xs">
                  <div className="px-3 py-2 border-b border-slate-800">
                    <p className="font-bold text-white flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4 text-emerald-400" />
                      <span>{isBn ? 'ভূমিকা ভিত্তিক এক্সেস কন্ট্রোল (RBAC)' : 'Role-Based Access Control'}</span>
                    </p>
                    <p className="text-[11px] text-slate-400">
                      {isBn ? 'সদস্য ভূমিকা পরিবর্তন করে টেস্ট করুন:' : 'Switch user to test role permissions:'}
                    </p>
                  </div>

                  <div className="py-1 space-y-1 max-h-56 overflow-y-auto">
                    {allMembers.filter(m => !m.isPlaceholder).map((m) => {
                      const isSelected = m.id === currentUser.id;
                      return (
                        <button
                          key={m.id}
                          onClick={() => {
                            soundEffects.playRoleAssign(soundEnabled);
                            onSwitchUser(m.id);
                            setIsRoleDropdownOpen(false);
                          }}
                          className={`w-full flex items-center justify-between p-2 rounded-xl transition text-left ${
                            isSelected ? 'bg-slate-800 text-white' : 'hover:bg-slate-800/60 text-slate-300'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{isBn ? m.nameBn : m.nameEn}</span>
                          </div>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${roleBadgeStyles[m.systemRole].bg} ${roleBadgeStyles[m.systemRole].text} ${roleBadgeStyles[m.systemRole].border}`}>
                            {m.systemRole}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="p-2 border-t border-slate-800 bg-slate-950/60 rounded-xl mt-1 text-[10px] text-slate-400">
                    <p className="font-semibold text-slate-300 mb-0.5">
                      {isBn ? 'অনুমতি নির্দেশিকা:' : 'Permission Guide:'}
                    </p>
                    <p>• <strong>Admin:</strong> {isBn ? 'পূর্ণ নিয়ন্ত্রণ, ভূমিকা প্রদান ও অডিট' : 'Full control, role assignment & audit'}</p>
                    <p>• <strong>Editor:</strong> {isBn ? 'দলিল ও প্রোফাইল যোগ/সম্পাদনা' : 'Add/edit documents & profiles'}</p>
                    <p>• <strong>Viewer:</strong> {isBn ? 'শুধুমাত্র তথ্য ও দলিল দেখার অনুমতি' : 'Read-only viewing'}</p>
                  </div>
                </div>
              )}
            </div>
            
            {/* Language Switcher */}
            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                onToggleLanguage();
              }}
              title={isBn ? 'Switch to English' : 'বাংলায় দেখুন'}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/70 text-xs font-semibold transition shadow-sm"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isBn ? 'EN' : 'বাংলা'}</span>
            </button>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                onToggleDarkMode();
              }}
              title="Toggle Theme"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700/70 transition"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-indigo-300" />}
            </button>

            {/* Vault Lock / Return to Login Page */}
            <button
              onClick={() => {
                soundEffects.playLock(soundEnabled);
                onLockVault();
              }}
              title={isBn ? 'ভল্ট লক করুন / লগআউট' : 'Lock Vault / Logout'}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/60 text-slate-300 hover:text-rose-300 border border-slate-700 hover:border-rose-700/60 text-xs font-semibold transition shadow-sm"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden md:inline">{isBn ? 'লগআউট' : 'Lock'}</span>
            </button>

          </div>
        </div>

        {/* Mobile / Tablet Navigation bar */}
        <div className="flex xl:hidden overflow-x-auto py-2 gap-1 scrollbar-none border-t border-slate-800 text-xs">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  soundEffects.playClick(soundEnabled);
                  onSelectTab(item.id);
                }}
                className={`px-3 py-1.5 whitespace-nowrap rounded-lg font-medium flex items-center gap-1.5 shrink-0 ${
                  isActive 
                    ? item.isSpecial ? 'bg-indigo-600 text-white' : 'bg-emerald-600 text-white' 
                    : 'text-slate-400 bg-slate-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{isBn ? item.labelBn : item.labelEn}</span>
                {item.badge && item.badge > 0 ? (
                  <span className={`px-1 rounded-full text-[9px] font-black ${
                    item.isSpecial ? 'bg-rose-500 text-white' : 'bg-amber-500 text-slate-950'
                  }`}>
                    {item.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>

      </div>
    </header>
  );
};
