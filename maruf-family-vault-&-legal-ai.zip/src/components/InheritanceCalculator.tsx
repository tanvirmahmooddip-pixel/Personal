import React, { useState } from 'react';
import { 
  Calculator, 
  Sparkles, 
  MapPin, 
  Coins, 
  Users, 
  HelpCircle, 
  CheckCircle2, 
  ShieldAlert,
  ArrowRight,
  PieChart
} from 'lucide-react';
import { Language } from '../types/family';

interface InheritanceCalculatorProps {
  language: Language;
}

export const InheritanceCalculator: React.FC<InheritanceCalculatorProps> = ({ language }) => {
  const isBn = language === 'bn';

  // Calculator inputs
  const [totalValuation, setTotalValuation] = useState<number>(10000000); // 1 Crore BDT
  const [totalDecimals, setTotalDecimals] = useState<number>(20.0); // 20 decimals
  const [wivesCount, setWivesCount] = useState<number>(1);
  const [sonsCount, setSonsCount] = useState<number>(3);
  const [daughtersCount, setDaughtersCount] = useState<number>(1);
  const [isMotherAlive, setIsMotherAlive] = useState<boolean>(true);
  const [activePreset, setActivePreset] = useState<'maruf' | 'custom'>('maruf');

  // Set Maruf Family Preset
  const applyMarufPreset = () => {
    setActivePreset('maruf');
    setTotalValuation(10000000);
    setTotalDecimals(20.0);
    setWivesCount(1); // Noor Akther
    setSonsCount(3); // Omar Faruque, Abdul Kader, Habibur Rahman
    setDaughtersCount(1); // Farjana Hossain
    setIsMotherAlive(true);
  };

  // Conversions
  const kathaEquivalent = (totalDecimals * 0.605).toFixed(2);
  const bighaEquivalent = (totalDecimals / 33.06).toFixed(2);

  // Calculation Logic under Islamic Hanafi Succession (Bangladesh Legal standard)
  // 1. Mother / Widow share:
  // If children exist, Wife (Widow) gets 1/8 (12.5%).
  const hasChildren = sonsCount > 0 || daughtersCount > 0;
  let motherSharePercent = 0;
  if (wivesCount > 0) {
    motherSharePercent = hasChildren ? 12.5 : 25.0;
  }

  const remainingPercent = 100 - motherSharePercent;

  // Split remaining among sons and daughters (Ratio 2 : 1)
  const totalParts = (sonsCount * 2) + (daughtersCount * 1);
  const partPercent = totalParts > 0 ? remainingPercent / totalParts : 0;
  const eachSonPercent = partPercent * 2;
  const eachDaughterPercent = partPercent;

  // Value distributions
  const motherMoney = (totalValuation * (motherSharePercent / 100));
  const motherDecimals = (totalDecimals * (motherSharePercent / 100));

  const sonMoney = (totalValuation * (eachSonPercent / 100));
  const sonDecimals = (totalDecimals * (eachSonPercent / 100));

  const daughterMoney = (totalValuation * (eachDaughterPercent / 100));
  const daughterDecimals = (totalDecimals * (eachDaughterPercent / 100));

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 border border-emerald-500/20 p-6 sm:p-8 shadow-xl">
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
            <Calculator className="w-3.5 h-3.5" />
            <span>{isBn ? 'মুসলিম পারিবারিক আইন ও ফারায়েয হিসাব' : 'Hanafi Muslim Succession & Land Distribution'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {isBn ? 'উত্তরাধিকার সম্পত্তি ও জমি বণ্টন ক্যালকুলেটর' : 'Estate & Land Inheritance Calculator'}
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed">
            {isBn
              ? 'মরহুম মোঃ আব্দুল বারিক ভূঁইয়ার রেখে যাওয়া স্থাবর জমি ও নগদ অর্থ ওয়ারিশদের (স্ত্রী, ৩ পুত্র, ১ কন্যা) মধ্যে আইনসম্মত বণ্টনের সঠিক গাণিতিক বিশ্লেষণ।'
              : 'Precise legal distribution of ancestral land and financial valuation for the heirs of Late Md. Abdul Barek Bhuyan.'}
          </p>
        </div>

        {/* Quick Maruf Preset Button */}
        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button
            onClick={applyMarufPreset}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition shadow ${
              activePreset === 'maruf'
                ? 'bg-emerald-600 text-white shadow-emerald-900/40 ring-2 ring-emerald-400'
                : 'bg-slate-800 text-slate-300 hover:text-white border border-slate-700'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{isBn ? 'মারুফের পরিবারের সঠিক সেটআপ (ডিফল্ট)' : "Maruf's Family Preset (Default)"}</span>
          </button>

          <button
            onClick={() => setActivePreset('custom')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold transition ${
              activePreset === 'custom'
                ? 'bg-indigo-600 text-white ring-2 ring-indigo-400'
                : 'bg-slate-800 text-slate-300 hover:text-white border border-slate-700'
            }`}
          >
            <span>{isBn ? 'কাস্টম হিসাব (সাধারণ)' : 'Custom Heirs Setup'}</span>
          </button>
        </div>
      </div>

      {/* Inputs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* Estate Value & Land Area Card */}
        <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700/60 shadow space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Coins className="w-4 h-4 text-emerald-400" />
            <span>{isBn ? 'সম্পত্তির মূল্য ও জমির পরিমাণ' : 'Estate Valuation & Land Area'}</span>
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'মোট সম্পত্তির আনুমানিক বাজারমূল্য (টাকা / BDT)' : 'Total Estate Value (BDT ৳)'}
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={totalValuation}
                  onChange={(e) => setTotalValuation(Number(e.target.value) || 0)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
                />
                <span className="absolute right-3.5 top-2.5 text-xs text-slate-400 font-bold">BDT</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'মোট জমির পরিমাণ (শতাংশ / Decimal)' : 'Total Land Area (Decimals)'}
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.01"
                  value={totalDecimals}
                  onChange={(e) => setTotalDecimals(Number(e.target.value) || 0)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
                />
                <span className="absolute right-3.5 top-2.5 text-xs text-slate-400 font-bold">শতাংশ</span>
              </div>
            </div>

            {/* Land Conversion Pill */}
            <div className="p-3 rounded-2xl bg-slate-900/70 border border-slate-800 text-xs text-slate-300 space-y-1">
              <span className="font-semibold text-emerald-400 block">{isBn ? 'বাংলাদেশি ভূমি পরিমাপ রূপান্তর:' : 'Land Measurement Equivalents:'}</span>
              <div className="flex justify-between">
                <span>{isBn ? 'কাঠা (Katha):' : 'Katha (0.605 / Decimal):'}</span>
                <span className="font-bold text-white">{kathaEquivalent} কাঠা</span>
              </div>
              <div className="flex justify-between">
                <span>{isBn ? 'বিঘা (Bigha):' : 'Bigha (33.06 Decimals / Bigha):'}</span>
                <span className="font-bold text-white">{bighaEquivalent} বিঘা</span>
              </div>
            </div>
          </div>
        </div>

        {/* Heirs Configuration Card */}
        <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700/60 shadow space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-400" />
            <span>{isBn ? 'উত্তরাধিকারীদের তথ্য' : 'Heirs Structure'}</span>
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'স্ত্রী / মাতা (নুর আক্তার)' : 'Wife / Mother'}
              </label>
              <select
                value={wivesCount}
                onChange={(e) => setWivesCount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
              >
                <option value={1}>{isBn ? '১ জন জীবিত (১/৮ অংশ)' : '1 Alive (1/8th)'}</option>
                <option value={0}>{isBn ? '০ জন (মৃত)' : '0 (Deceased)'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'পুত্রদের সংখ্যা' : 'Number of Sons'}
              </label>
              <input
                type="number"
                min={0}
                max={10}
                value={sonsCount}
                onChange={(e) => setSonsCount(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'কন্যাদের সংখ্যা' : 'Number of Daughters'}
              </label>
              <input
                type="number"
                min={0}
                max={10}
                value={daughtersCount}
                onChange={(e) => setDaughtersCount(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'আইনি বিধি' : 'Legal Standard'}
              </label>
              <div className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-emerald-400 text-xs font-semibold">
                {isBn ? 'হানাফি আইন (২:১ অনুপাত)' : 'Hanafi Law (2:1 Ratio)'}
              </div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-800/40 text-xs text-emerald-200">
            {isBn
              ? 'সন্তান থাকলে স্ত্রী/মাতা পান মোট সম্পত্তির ১/৮ অংশ (১২.৫%)। অবশিষ্ট ৭/৮ অংশ পুত্র ও কন্যাদের মধ্যে ২:১ অনুপাতে বণ্টিত হয়।'
              : 'With children present, the mother/widow receives 1/8th (12.5%). The remaining 7/8ths are shared by sons and daughters at a 2:1 ratio.'}
          </div>
        </div>

      </div>

      {/* Calculated Distribution Results */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-850 border border-slate-700 shadow-xl space-y-6">
        <div className="flex items-center justify-between border-b border-slate-700/60 pb-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <PieChart className="w-5 h-5 text-emerald-400" />
              <span>{isBn ? 'আইনসম্মত অংশীদারিত্ব ও বণ্টনের ফলাফল' : 'Legal Share Entitlement Breakdown'}</span>
            </h2>
            <p className="text-xs text-slate-400">
              {isBn ? 'প্রত্যেক ওয়ারিশের প্রাপ্য অংশ, নগদ টাকার পরিমাণ ও জমির খতিয়ান হিস্যা' : 'Exact financial entitlement and land decimals per heir.'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Mother Card */}
          {wivesCount > 0 && (
            <div className="p-5 rounded-2xl bg-gradient-to-b from-slate-800 to-slate-900 border border-emerald-500/40 shadow space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {isBn ? 'মাতা / বিধবা স্ত্রী' : 'Mother / Widow'}
                </span>
                <span className="text-sm font-bold text-emerald-400">{motherSharePercent.toFixed(2)}%</span>
              </div>
              <h4 className="text-base font-extrabold text-white">
                {isBn ? 'নুর আক্তার' : 'Noor Akther'}
              </h4>
              <div className="space-y-1.5 text-xs text-slate-300 pt-2 border-t border-slate-700/50">
                <div className="flex justify-between">
                  <span>{isBn ? 'আইনি হিস্যা:' : 'Legal Fraction:'}</span>
                  <span className="font-semibold text-white">১/৮ অংশ (12.5%)</span>
                </div>
                <div className="flex justify-between">
                  <span>{isBn ? 'প্রাপ্য অর্থ:' : 'Entitled Value:'}</span>
                  <span className="font-bold text-emerald-400 font-mono">৳ {motherMoney.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span>{isBn ? 'প্রাপ্য জমি:' : 'Entitled Land:'}</span>
                  <span className="font-bold text-white font-mono">{motherDecimals.toFixed(2)} শতাংশ ({(motherDecimals * 0.605).toFixed(2)} কাঠা)</span>
                </div>
              </div>
            </div>
          )}

          {/* Sons Card */}
          {sonsCount > 0 && (
            <div className="p-5 rounded-2xl bg-gradient-to-b from-slate-800 to-slate-900 border border-blue-500/40 shadow space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  {isBn ? `প্রত্যেক পুত্র (${sonsCount} জন)` : `Each Son (${sonsCount})`}
                </span>
                <span className="text-sm font-bold text-blue-400">{eachSonPercent.toFixed(2)}%</span>
              </div>
              <h4 className="text-base font-extrabold text-white">
                {isBn ? 'ওমর ফারুক, আব্দুল কাদের, মারুফ' : 'Omar Faruque, Abdul Kader, Maruf'}
              </h4>
              <div className="space-y-1.5 text-xs text-slate-300 pt-2 border-t border-slate-700/50">
                <div className="flex justify-between">
                  <span>{isBn ? 'আইনি হিস্যা:' : 'Legal Fraction:'}</span>
                  <span className="font-semibold text-white">২/৮ = ১/৪ অংশ (25.0%)</span>
                </div>
                <div className="flex justify-between">
                  <span>{isBn ? 'প্রাপ্য অর্থ (জনপ্রতি):' : 'Value (Each):'}</span>
                  <span className="font-bold text-blue-400 font-mono">৳ {sonMoney.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span>{isBn ? 'প্রাপ্য জমি (জনপ্রতি):' : 'Land (Each):'}</span>
                  <span className="font-bold text-white font-mono">{sonDecimals.toFixed(2)} শতাংশ ({(sonDecimals * 0.605).toFixed(2)} কাঠা)</span>
                </div>
              </div>
            </div>
          )}

          {/* Daughters Card */}
          {daughtersCount > 0 && (
            <div className="p-5 rounded-2xl bg-gradient-to-b from-slate-800 to-slate-900 border border-pink-500/40 shadow space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30">
                  {isBn ? `প্রত্যেক কন্যা (${daughtersCount} জন)` : `Each Daughter (${daughtersCount})`}
                </span>
                <span className="text-sm font-bold text-pink-400">{eachDaughterPercent.toFixed(2)}%</span>
              </div>
              <h4 className="text-base font-extrabold text-white">
                {isBn ? 'ফারজানা হোসেন' : 'Farjana Hossain'}
              </h4>
              <div className="space-y-1.5 text-xs text-slate-300 pt-2 border-t border-slate-700/50">
                <div className="flex justify-between">
                  <span>{isBn ? 'আইনি হিস্যা:' : 'Legal Fraction:'}</span>
                  <span className="font-semibold text-white">১/৮ অংশ (12.5%)</span>
                </div>
                <div className="flex justify-between">
                  <span>{isBn ? 'প্রাপ্য অর্থ:' : 'Entitled Value:'}</span>
                  <span className="font-bold text-pink-400 font-mono">৳ {daughterMoney.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span>{isBn ? 'প্রাপ্য জমি:' : 'Entitled Land:'}</span>
                  <span className="font-bold text-white font-mono">{daughterDecimals.toFixed(2)} শতাংশ ({(daughterDecimals * 0.605).toFixed(2)} কাঠা)</span>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Legal Disclaimer & Verification note */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-200">
              {isBn ? 'বণ্টননামা দলিল (Partition Deed) রেজিস্ট্রি সংক্রান্ত সতর্কতা:' : 'Notice on Bontonnama (Partition Deed) Registration:'}
            </span>
            <p className="mt-0.5 leading-relaxed">
              {isBn 
                ? 'ওয়ারিশ সূত্রে প্রাপ্ত জমি যেকোনো ওয়ারিশ বিক্রি করতে চাইলে অথবা পৃথকভাবে ভোগদখল করতে চাইলে অবশ্যই সকল ওয়ারিশদের উপস্থিতিতে ও স্বাক্ষরে একটি রেজিস্ট্রিকৃত বণ্টননামা দলিল সম্পাদন করতে হবে। এটি ছাড়া ক্রেতা চূড়ান্ত নামজারি করতে পারেন না।'
                : 'To legally sell or demarcate individual portions of inherited land, all legal heirs must sign a registered Bontonnama Deed at the Sub-Registry Office.'}
            </p>
          </div>
        </div>

      </div>

    </div>
  );
};
