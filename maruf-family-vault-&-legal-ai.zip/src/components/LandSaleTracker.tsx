import React, { useState } from 'react';
import { 
  FileText, 
  CheckCircle2, 
  ExternalLink, 
  HelpCircle, 
  AlertCircle, 
  ChevronRight, 
  Clock, 
  Download, 
  Printer, 
  Sparkles,
  ShieldCheck,
  Building2,
  PhoneCall
} from 'lucide-react';
import { Language } from '../types/family';

interface LandSaleTrackerProps {
  language: Language;
}

export const LandSaleTracker: React.FC<LandSaleTrackerProps> = ({ language }) => {
  const isBn = language === 'bn';
  const [activeStep, setActiveStep] = useState<number>(1);

  // 8 Mandatory Documents Checklist state
  const [checklist, setChecklist] = useState<{ id: string; titleBn: string; titleEn: string; isReady: boolean; descBn: string; descEn: string }[]>([
    {
      id: 'death_cert',
      titleBn: '১. মরহুম পিতার মৃত্যু সনদ (Death Certificate)',
      titleEn: '1. Death Certificate of Late Father',
      isReady: true,
      descBn: 'ইউনিয়ন পরিষদ বা সিটি কর্পোরেশন কর্তৃক স্বাক্ষরিত বৈধ সনদ।',
      descEn: 'Official certificate signed by local Union Parishad or City Corp.',
    },
    {
      id: 'warish_sanad',
      titleBn: '২. ওয়ারিশ সনদ বা উত্তরাধিকার সার্টিফিকেট (Warish Sanad)',
      titleEn: '2. Warish Sanad (Heir Certificate)',
      isReady: true,
      descBn: 'চেয়ারম্যান/কাউন্সিলর কর্তৃক ইস্যুকৃত। স্ত্রী, ৩ ভাই ও ১ বোনের নাম তালিকাভুক্ত।',
      descEn: 'Signed by Chairman/Councillor listing mother, 3 sons, and 1 daughter.',
    },
    {
      id: 'nid_passport',
      titleBn: '৩. সকল ওয়ারিশের জাতীয় পরিচয়পত্র ও পাসপোর্ট কপি',
      titleEn: '3. NID & Passport Copies of all Heirs',
      isReady: true,
      descBn: 'নুর আক্তার, ওমর ফারুক, আব্দুল কাদের, মারুফ ও ফারজানার এনআইডি।',
      descEn: 'Smart NIDs of mother, all brothers, and sister.',
    },
    {
      id: 'original_deeds',
      titleBn: '৪. মূল মালিকানা কবলা দলিল ও পূর্ববর্তী বায়া দলিল (Via Deeds)',
      titleEn: '4. Original Title Deeds & Chain Via Deeds',
      isReady: true,
      descBn: 'পিতার নামের রেজিস্ট্রি কবলা দলিল এবং পূর্বের ধারাবাহিক রেকর্ড।',
      descEn: 'Original Registered deeds in fathers name and previous chain.',
    },
    {
      id: 'khatian_porcha',
      titleBn: '৫. সিএস, এসএ, আরএস ও বিএস খতিয়ান বা পরচা কপি',
      titleEn: '5. CS, SA, RS, and BS Khatian Records',
      isReady: true,
      descBn: 'মৌজা ও দাগ নম্বর সম্বলিত সর্বশেষ ডিজিটাল জরিপ পরচা।',
      descEn: 'Latest digital survey records with mouza and plot numbers.',
    },
    {
      id: 'namjari_khatian',
      titleBn: '৬. ওয়ারিশগণের যৌথ ই-নামজারি খতিয়ান ও ডিসিআর (DCR)',
      titleEn: '6. Joint Mutation Khatian & DCR Receipt',
      isReady: false,
      descBn: 'পিতার নাম পরিবর্তন করে সকল ওয়ারিশের যৌথ নামে খতিয়ান খোলার কপি।',
      descEn: 'AC Land mutation transferring title from father to joint heirs.',
    },
    {
      id: 'khajna_receipt',
      titleBn: '৭. চলতি অর্থ-বছরের হালনাগাদ ভূমি উন্নয়ন কর (খাজনা দাখিলা)',
      titleEn: '7. Up-to-Date Land Development Tax Receipts',
      isReady: true,
      descBn: 'বকেয়া মুক্ত খাজনা পরিশোধের সরকারি রসিদ।',
      descEn: 'Government tax clearance receipt without any arrears.',
    },
    {
      id: 'bontonnama_deed',
      titleBn: '৮. রেজিস্ট্রিকৃত পারিবারিক বণ্টননামা দলিল (Partition Deed)',
      titleEn: '8. Registered Partition Deed (Bontonnama)',
      isReady: false,
      descBn: 'নির্দিষ্ট প্লট বিক্রির পূর্বে সকল ভাই-বোন ও মাতার স্বাক্ষরে রেজিস্ট্রি করতে হবে।',
      descEn: 'Legally registered demarcation deed signed by all surviving heirs.',
    },
  ]);

  const toggleChecklist = (id: string) => {
    setChecklist((prev) =>
      prev.map((item) => (item.id === id ? { ...item, isReady: !item.isReady } : item))
    );
  };

  const steps = [
    {
      step: 1,
      titleBn: 'ধাপ ১: পোর্টাল রেজিস্ট্রেশন ও লগইন',
      titleEn: 'Step 1: Portal Registration & Login',
      portalUrl: 'https://mutation.land.gov.bd',
      descBn: 'mutation.land.gov.bd পোর্টালে মোবাইল নম্বর ও এনআইডি দিয়ে সিটিজেন অ্যাকাউন্ট লগইন করুন। ওটিপি (OTP) যাচাইকরণ সম্পন্ন করুন।',
      descEn: 'Visit mutation.land.gov.bd and login using mobile number & NID with OTP verification.',
    },
    {
      step: 2,
      titleBn: 'ধাপ ২: নামজারির ধরন নির্বাচন (ওয়ারিশ সূত্রে)',
      titleEn: 'Step 2: Select Mutation Type (Warish / Inheritance)',
      descBn: 'নামজারি আবেদনের ধরনে "ওয়ারিশ সূত্রে" (Inheritance) অপশন নির্বাচন করুন। পিতা মরহুম মোঃ আব্দুল বারিক ভূঁইয়ার নাম পূর্ববর্তী রেকর্ডমালিক হিসেবে দিন।',
      descEn: 'Select "Inheritance / Warish" transfer type from the dropdown.',
    },
    {
      step: 3,
      titleBn: 'ধাপ ৩: মৌজা, দাগ ও খতিয়ান নির্বাচন',
      titleEn: 'Step 3: Location Details & Plot/Khatian Selection',
      descBn: 'বিভাগ, জেলা, উপজেলা/সার্কেল ও ইউনিয়ন/মৌজা ধাপে ধাপে নির্বাচন করুন। সিএস, এসএ, আরএস বা বিএস খতিয়ান ও দাগ নম্বর লিখুন।',
      descEn: 'Choose Division -> District -> Upazila -> Mouza. Enter CS/SA/RS/BS Khatian and Plot numbers.',
    },
    {
      step: 4,
      titleBn: 'ধাপ ৪: ওয়ারিশগণের তথ্য ও হিস্যা প্রদান',
      titleEn: 'Step 4: Heirs Information & Share Percentages',
      descBn: 'ওয়ারিশ সনদ অনুযায়ী সকল ওয়ারিশের নাম, এনআইডি ও ঠিকানা যোগ করুন (মাতা নুর আক্তার ১২.৫%, ৩ ভাই প্রত্যেকে ২৫%, ১ বোন ১২.৫%)।',
      descEn: 'Enter all legal heirs with exact percentages according to Warish Sanad.',
    },
    {
      step: 5,
      titleBn: 'ধাপ ৫: প্রয়োজনীয় নথিপত্র আপলোড',
      titleEn: 'Step 5: Digital Document Scans Upload',
      descBn: 'পিতার মৃত্যু সনদ, ওয়ারিশ সনদ, মূল দলিল, সর্বশেষ খতিয়ান ও খাজনা রসিদের স্পষ্ট স্ক্যান কপি (PDF/JPEG) আপলোড করুন।',
      descEn: 'Upload PDF/JPEG scans of death cert, warish sanad, deeds, and tax receipts.',
    },
    {
      step: 6,
      titleBn: 'ধাপ ৬: সরকারি ফি পরিশোধ ও ট্র্যাকিং নম্বর সংগ্রহ',
      titleEn: 'Step 6: Online Fee Payment & Tracking Number',
      descBn: 'বিকাশ, নগদ বা রকেটের মাধ্যমে সরকারি আবেদন ফি (২০ টাকা) পরিশোধ করে আবেদন সাবমিট করুন। ট্র্যাকিং স্লিপ প্রিন্ট করুন।',
      descEn: 'Pay online fee via bKash/Nagad and download application tracking slip.',
    },
  ];

  const readyCount = checklist.filter((c) => c.isReady).length;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 border border-emerald-500/20 p-6 sm:p-8 shadow-xl">
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
            <Building2 className="w-3.5 h-3.5" />
            <span>{isBn ? 'ভূমি মন্ত্রণালয় বাংলাদেশ ও এসি ল্যান্ড অফিস গাইড' : 'Ministry of Land Bangladesh & AC Land Office'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {isBn ? 'ই-নামজারি ও ওয়ারিশ জমি বিক্রির সম্পূর্ণ নির্দেশিকা' : 'e-Mutation (e-Namjari) & Land Sale Blueprint'}
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed">
            {isBn
              ? 'বাংলাদেশে পৈতৃক ওয়ারিশ জমি বিক্রয় ও নামজারি করার সরকারি ৬টি ধাপ এবং বাধ্যতামূলক ৮টি দলিলের চেকলিস্ট।'
              : 'Complete statutory guide for online e-Namjari application and the mandatory 8-document legal checklist for selling inherited land in Bangladesh.'}
          </p>
        </div>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <a
            href="https://mutation.land.gov.bd"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-900/40 transition"
          >
            <span>{isBn ? 'সরকারি ই-নামজারি পোর্টালে যান' : 'Go to mutation.land.gov.bd'}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <button
            onClick={() => window.print()}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-semibold transition"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isBn ? 'চেকলিস্ট প্রিন্ট / সেভ করুন' : 'Print Checklist'}</span>
          </button>
        </div>
      </div>

      {/* 8 Mandatory Documents Checklist */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-850 border border-slate-700 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-700/60 pb-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>{isBn ? 'ওয়ারিশ জমি বিক্রির জন্য ৮টি আবশ্যকীয় দলিল' : 'Mandatory 8-Document Legal Checklist'}</span>
            </h2>
            <p className="text-xs text-slate-400">
              {isBn 
                ? 'আইনি ঝামেলামুক্তভাবে জমি রেজিস্ট্রি ও ক্রেতার কাছে হস্তান্তর করতে এই দলিলগুলো প্রস্তুত থাকতে হবে।' 
                : 'All 8 documents are required for seamless registration and legal conveyance at the Sub-Registry office.'}
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-750 text-xs font-semibold">
            <span className="text-slate-400">{isBn ? 'প্রস্তুত আছে:' : 'Ready:'}</span>
            <span className="text-emerald-400 font-bold">{readyCount} / {checklist.length}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {checklist.map((item) => (
            <div
              key={item.id}
              onClick={() => toggleChecklist(item.id)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start gap-3.5 ${
                item.isReady
                  ? 'bg-slate-900/90 border-emerald-500/50 hover:border-emerald-400 shadow-sm'
                  : 'bg-slate-900/40 border-amber-500/40 hover:border-amber-400'
              }`}
            >
              <div className={`mt-0.5 p-1 rounded-lg ${item.isReady ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-500 border border-slate-700'}`}>
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div className="space-y-1">
                <h4 className={`text-xs font-bold leading-snug ${item.isReady ? 'text-white' : 'text-amber-300'}`}>
                  {isBn ? item.titleBn : item.titleEn}
                </h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {isBn ? item.descBn : item.descEn}
                </p>
                <span className={`inline-block text-[10px] font-bold px-2 py-0.2 rounded-full ${
                  item.isReady ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                }`}>
                  {item.isReady ? (isBn ? '✓ প্রস্তুত রয়েছে' : '✓ Ready') : (isBn ? 'সংগ্রহ প্রয়োজন' : 'Action Required')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Step by Step Online e-Namjari Process */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-850 border border-slate-700 shadow-xl space-y-6">
        <div className="border-b border-slate-700/60 pb-4">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-400" />
            <span>{isBn ? 'ই-নামজারি অনলাইন আবেদন প্রক্রিয়া (ধাপে ধাপে)' : 'Step-by-Step e-Namjari Application Workflow'}</span>
          </h2>
          <p className="text-xs text-slate-400">
            {isBn ? 'সহকারী কমিশনার (ভূমি) / AC Land অফিসে আবেদনের নিয়ম' : 'Procedure to submit mutation online with AC Land office.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {steps.map((s) => (
            <div
              key={s.step}
              onClick={() => setActiveStep(s.step)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                activeStep === s.step
                  ? 'bg-gradient-to-b from-slate-800 to-slate-900 border-emerald-500 ring-1 ring-emerald-500/40 shadow-lg'
                  : 'bg-slate-900/60 border-slate-700/60 hover:border-slate-600'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs ${
                    activeStep === s.step ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {s.step}
                  </span>
                  {s.portalUrl && (
                    <span className="text-[10px] text-emerald-400 font-semibold underline">
                      Online Portal
                    </span>
                  )}
                </div>
                <h4 className="font-bold text-xs text-white">
                  {isBn ? s.titleBn : s.titleEn}
                </h4>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {isBn ? s.descBn : s.descEn}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400 font-medium">
                <span>{activeStep === s.step ? (isBn ? 'সক্রিয় ধাপ' : 'Active Step') : (isBn ? 'বিস্তারিত ক্লিক করুন' : 'Click for details')}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </div>
          ))}
        </div>

        {/* AC Land Office Shunani & Hearing Details */}
        <div className="p-5 rounded-2xl bg-indigo-950/30 border border-indigo-800/40 text-xs text-indigo-200 space-y-2">
          <div className="flex items-center gap-2 font-bold text-indigo-300">
            <Clock className="w-4 h-4" />
            <span>{isBn ? 'এসি ল্যান্ড অফিস শুনানি (Hearing) ও খতিয়ান সংগ্রহ:' : 'AC Land Hearing & Certified Porcha Collection:'}</span>
          </div>
          <p className="leading-relaxed">
            {isBn 
              ? 'অনলাইনে আবেদন দাখিলের পর কানুনগো ও ইউনিয়ন ভূমি সহকারী কর্মকর্তা সরেজমিনে পরিদর্শন ও রিপোর্ট প্রদান করবেন। এরপর শুনানির জন্য এসএমএস (SMS) আসবে। শুনানির দিন সকল মূল দলিল, ওয়ারিশ সনদ, এনআইডি ও খাজনা দাখিলা সহ উপস্থিত হতে হবে। অনুমোদন পেলে ডিসিআর ফি (১,১০০ টাকা) পরিশোধ করে অনলাইন নামজারি খতিয়ান ডাউনলোড করা যাবে।'
              : 'After online submission, a hearing date will be scheduled via SMS. Bring all original physical deeds, Warish Sanad, and NIDs to the AC Land office. Upon final approval, pay the 1,100 BDT DCR fee to download the certified Namjari Khatian.'}
          </p>
        </div>

      </div>

    </div>
  );
};
