import React, { useState } from 'react';
import { 
  X, 
  Phone, 
  Mail, 
  MapPin, 
  Heart, 
  Briefcase, 
  Shield, 
  FileCheck2, 
  Download, 
  Lock, 
  Edit3, 
  Users, 
  CheckCircle2,
  Calendar,
  Sparkles
} from 'lucide-react';
import { FamilyMember, VaultDocument, Language, UserRole } from '../types/family';

interface MemberDetailModalProps {
  member: FamilyMember;
  allMembers: FamilyMember[];
  documents: VaultDocument[];
  language: Language;
  userRole: UserRole;
  onClose: () => void;
  onSelectAnotherMember: (member: FamilyMember) => void;
  onUpdateMember: (updated: FamilyMember) => void;
  isAdminLoggedIn: boolean;
}

export const MemberDetailModal: React.FC<MemberDetailModalProps> = ({
  member,
  allMembers,
  documents,
  language,
  userRole,
  onClose,
  onSelectAnotherMember,
  onUpdateMember,
  isAdminLoggedIn,
}) => {
  const isBn = language === 'bn';
  const canEdit = userRole === 'Admin' || userRole === 'Editor';
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({ ...member });

  // Filter vault documents belonging to this member
  const memberDocs = documents.filter((d) => d.memberId === member.id);

  // Helper to resolve related member object
  const getMemberById = (id?: string) => allMembers.find((m) => m.id === id);

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateMember(formData);
    setIsEditing(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-3xl bg-slate-900 border border-slate-700/80 shadow-2xl overflow-hidden my-auto">
        
        {/* Modal Top Banner */}
        <div className="relative bg-gradient-to-r from-emerald-900 via-slate-800 to-indigo-950 p-6 sm:p-8 border-b border-slate-700/60">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
            <div className={`w-20 h-20 rounded-3xl flex items-center justify-center font-bold text-2xl shadow-xl ${member.avatarColor}`}>
              {member.nameBn.slice(0, 2)}
            </div>
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  {isBn ? member.roleBn : member.roleEn}
                </span>
                <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${
                  member.systemRole === 'Admin' 
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' 
                    : member.systemRole === 'Editor' 
                    ? 'bg-blue-500/20 text-blue-300 border-blue-500/40' 
                    : 'bg-slate-700/80 text-slate-300 border-slate-600'
                }`}>
                  {member.systemRole}
                </span>
                {member.bloodGroup && (
                  <span className="text-xs font-bold px-2 py-0.5 rounded-lg bg-rose-950 text-rose-300 border border-rose-800">
                    {member.bloodGroup}
                  </span>
                )}
                {member.isDeceased && (
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-lg bg-slate-700 text-slate-300">
                    {isBn ? 'মরহুম' : 'Late'}
                  </span>
                )}
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {isBn ? member.nameBn : member.nameEn}
              </h2>
              <p className="text-sm text-slate-300 font-medium">
                {isBn ? member.nameEn : member.nameBn}
              </p>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
          
          {/* Edit Form (If editing by Admin) */}
          {isEditing ? (
            <form onSubmit={handleSaveEdit} className="space-y-4 bg-slate-800/60 p-5 rounded-2xl border border-slate-700">
              <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                <Edit3 className="w-4 h-4" />
                <span>{isBn ? 'সদস্যের তথ্য সম্পাদনা করুন' : 'Edit Member Details'}</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'নাম (বাংলা)' : 'Name (Bangla)'}
                  </label>
                  <input
                    type="text"
                    value={formData.nameBn}
                    onChange={(e) => setFormData({ ...formData, nameBn: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'নাম (English)' : 'Name (English)'}
                  </label>
                  <input
                    type="text"
                    value={formData.nameEn}
                    onChange={(e) => setFormData({ ...formData, nameEn: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'সম্পর্ক / পদবি (বাংলা)' : 'Role / Relationship (Bangla)'}
                  </label>
                  <input
                    type="text"
                    value={formData.roleBn}
                    onChange={(e) => setFormData({ ...formData, roleBn: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'মোবাইল নম্বর' : 'Phone Number'}
                  </label>
                  <input
                    type="text"
                    value={formData.phone || ''}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'রক্তের গ্রুপ' : 'Blood Group'}
                  </label>
                  <input
                    type="text"
                    value={formData.bloodGroup || ''}
                    onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'পেশা' : 'Occupation'}
                  </label>
                  <input
                    type="text"
                    value={formData.occupationBn || ''}
                    onChange={(e) => setFormData({ ...formData, occupationBn: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                {isAdminLoggedIn && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {isBn ? 'সিস্টেম ভূমিকা (RBAC Access Role)' : 'System Role (RBAC)'}
                    </label>
                    <select
                      value={formData.systemRole}
                      onChange={(e) => setFormData({ ...formData, systemRole: e.target.value as UserRole })}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="Admin">Admin ({isBn ? 'পূর্ণ নিয়ন্ত্রণ' : 'Full Control'})</option>
                      <option value="Editor">Editor ({isBn ? 'দলিল ও তথ্য সম্পাদনাকারী' : 'Edit documents & profiles'})</option>
                      <option value="Viewer">Viewer ({isBn ? 'শুধুমাত্র দেখার অনুমতি' : 'Read-only'})</option>
                    </select>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold transition"
                >
                  {isBn ? 'সংরক্ষণ করুন' : 'Save Changes'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs transition"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
              </div>
            </form>
          ) : null}

          {/* Contact & Bio Info Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/60 space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                {isBn ? 'যোগাযোগ ও পরিচয়' : 'Contact & Identity'}
              </h4>
              <div className="space-y-2 text-xs">
                {member.phone && (
                  <div className="flex items-center gap-2 text-slate-200">
                    <Phone className="w-4 h-4 text-emerald-400" />
                    <span>{member.phone}</span>
                  </div>
                )}
                {member.email && (
                  <div className="flex items-center gap-2 text-slate-200">
                    <Mail className="w-4 h-4 text-emerald-400" />
                    <span>{member.email}</span>
                  </div>
                )}
                {member.addressBn && (
                  <div className="flex items-center gap-2 text-slate-200">
                    <MapPin className="w-4 h-4 text-emerald-400" />
                    <span>{isBn ? member.addressBn : member.addressEn}</span>
                  </div>
                )}
                {member.nidOrBirthCert && (
                  <div className="flex items-center gap-2 text-slate-200">
                    <Shield className="w-4 h-4 text-emerald-400" />
                    <span>{member.nidOrBirthCert}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/60 space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                {isBn ? 'পেশা ও অতিরিক্ত নোট' : 'Occupation & Notes'}
              </h4>
              <div className="space-y-2 text-xs text-slate-300">
                {member.occupationBn && (
                  <div className="flex items-center gap-2">
                    <Briefcase className="w-4 h-4 text-emerald-400" />
                    <span>{isBn ? member.occupationBn : member.occupationEn}</span>
                  </div>
                )}
                {member.notesBn ? (
                  <p className="text-slate-300 leading-relaxed italic bg-slate-900/50 p-2.5 rounded-xl border border-slate-750">
                    {isBn ? member.notesBn : member.notesEn}
                  </p>
                ) : (
                  <p className="text-slate-500 italic">
                    {isBn ? 'কোনো অতিরিক্ত নোট যোগ করা হয়নি।' : 'No additional notes added.'}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Family Relations Tree Links */}
          <div className="p-5 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              <span>{isBn ? 'পারিবারিক সম্পর্ক ও বন্ধন' : 'Family Lineage & Relations'}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {/* Father */}
              {member.relationships.father && (
                <div 
                  onClick={() => {
                    const f = getMemberById(member.relationships.father);
                    if (f) onSelectAnotherMember(f);
                  }}
                  className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-700/50 hover:border-emerald-500/50 cursor-pointer transition text-xs"
                >
                  <span className="text-[10px] text-slate-400 block">{isBn ? 'পিতা:' : 'Father:'}</span>
                  <span className="font-semibold text-white">
                    {getMemberById(member.relationships.father)?.nameBn || member.relationships.father}
                  </span>
                </div>
              )}

              {/* Mother */}
              {member.relationships.mother && (
                <div 
                  onClick={() => {
                    const m = getMemberById(member.relationships.mother);
                    if (m) onSelectAnotherMember(m);
                  }}
                  className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-700/50 hover:border-emerald-500/50 cursor-pointer transition text-xs"
                >
                  <span className="text-[10px] text-slate-400 block">{isBn ? 'মাতা:' : 'Mother:'}</span>
                  <span className="font-semibold text-white">
                    {getMemberById(member.relationships.mother)?.nameBn || member.relationships.mother}
                  </span>
                </div>
              )}

              {/* Spouse */}
              {member.relationships.spouse && (
                <div 
                  onClick={() => {
                    const s = getMemberById(member.relationships.spouse);
                    if (s) onSelectAnotherMember(s);
                  }}
                  className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-700/50 hover:border-emerald-500/50 cursor-pointer transition text-xs"
                >
                  <span className="text-[10px] text-slate-400 block">{isBn ? 'স্বামী/স্ত্রী:' : 'Spouse:'}</span>
                  <span className="font-semibold text-white">
                    {getMemberById(member.relationships.spouse)?.nameBn || member.relationships.spouse}
                  </span>
                </div>
              )}

              {/* Children */}
              {member.relationships.children && member.relationships.children.length > 0 && (
                <div className="sm:col-span-2 md:col-span-3 p-3 rounded-xl bg-slate-900/80 border border-slate-700/50 text-xs space-y-1.5">
                  <span className="text-[10px] text-slate-400 block font-semibold">
                    {isBn ? 'সন্তান-সন্ততি:' : 'Children:'}
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {member.relationships.children.map((childId) => {
                      const child = getMemberById(childId);
                      return (
                        <button
                          key={childId}
                          onClick={() => child && onSelectAnotherMember(child)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white border border-slate-700 text-xs font-medium transition"
                        >
                          {child ? (isBn ? child.nameBn : child.nameEn) : childId}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Dedicated Member Documents in Vault */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-emerald-400" />
                <span>
                  {isBn 
                    ? `সংরক্ষিত ব্যক্তিগত দলিল ও সনদ (${memberDocs.length}টি)` 
                    : `Personal Vault Documents (${memberDocs.length})`}
                </span>
              </h4>
            </div>

            {memberDocs.length > 0 ? (
              <div className="space-y-2">
                {memberDocs.map((doc) => (
                  <div 
                    key={doc.id}
                    className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/70 hover:border-slate-600 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                        <Lock className="w-4 h-4" />
                      </div>
                      <div>
                        <h5 className="font-semibold text-white">
                          {isBn ? doc.titleBn : doc.titleEn}
                        </h5>
                        <p className="text-[11px] text-slate-400">
                          {doc.documentNumber} • {doc.fileSize} • {doc.encryptionHash}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                        AES-256
                      </span>
                      <button 
                        onClick={() => alert(isBn ? `"${doc.titleBn}" নিরাপদে ডিক্রিপ্ট ও ডাউনলোড করা হচ্ছে...` : `Decrypting & downloading "${doc.titleEn}"...`)}
                        className="p-2 rounded-xl bg-slate-700 hover:bg-emerald-600 text-white transition"
                        title={isBn ? 'ডাউনলোড' : 'Download'}
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-slate-800/30 border border-dashed border-slate-700 text-center text-xs text-slate-400">
                {isBn 
                  ? 'এই সদস্যের জন্য এখনও সরাসরি কোনো দলিল আপলোড করা হয়নি।' 
                  : 'No specific documents uploaded for this member yet.'}
              </div>
            )}
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-6 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
          <div>
            {canEdit && !isEditing ? (
              <button
                onClick={() => setIsEditing(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>{isBn ? 'তথ্য পরিবর্তন করুন (Edit)' : 'Edit Member'}</span>
              </button>
            ) : !canEdit ? (
              <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-slate-500" />
                <span>{isBn ? 'ভিউয়ার মোড: শুধুমাত্র দর্শনাধিকার' : 'Viewer Mode: Read-only access'}</span>
              </span>
            ) : null}
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
          >
            {isBn ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>

      </div>
    </div>
  );
};
