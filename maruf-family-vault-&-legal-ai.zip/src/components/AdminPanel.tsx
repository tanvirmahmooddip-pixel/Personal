import React, { useState } from 'react';
import { 
  UserCheck, 
  Users, 
  FileCheck2, 
  Check, 
  X, 
  Trash2, 
  Edit3, 
  Plus, 
  Sliders, 
  ShieldAlert, 
  Clock, 
  Sparkles, 
  Key, 
  Server, 
  Lock, 
  Eye, 
  EyeOff,
  BellRing,
  Shield,
  UserCog,
  CheckCircle2,
  AlertCircle,
  Activity
} from 'lucide-react';
import { FamilyMember, VaultDocument, VisitorRequest, AdminSettings, Language, UserRole, ROLE_PERMISSIONS, AuditLogEntry } from '../types/family';
import { AuditTrail } from './AuditTrail';

interface AdminPanelProps {
  members: FamilyMember[];
  documents: VaultDocument[];
  requests: VisitorRequest[];
  logs: AuditLogEntry[];
  settings: AdminSettings;
  language: Language;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onUpdateMember: (member: FamilyMember) => void;
  onDeleteMember: (id: string) => void;
  onOpenAddMemberModal: () => void;
  onApproveRequest: (id: string) => void;
  onRejectRequest: (id: string) => void;
  onUpdateSettings: (settings: AdminSettings) => void;
  onAssignRole: (memberId: string, newRole: UserRole) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  members,
  documents,
  requests,
  logs,
  settings,
  language,
  soundEnabled,
  onToggleSound,
  onUpdateMember,
  onDeleteMember,
  onOpenAddMemberModal,
  onApproveRequest,
  onRejectRequest,
  onUpdateSettings,
  onAssignRole,
}) => {
  const isBn = language === 'bn';
  const [activeSubTab, setActiveSubTab] = useState<'audit' | 'roles' | 'requests' | 'members' | 'theme' | 'cron'>('audit');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [roleSearchQuery, setRoleSearchQuery] = useState('');
  const [roleUpdateToast, setRoleUpdateToast] = useState<{ name: string; role: UserRole } | null>(null);
  const [cronTestResponse, setCronTestResponse] = useState<any | null>(null);
  const [isTestingCron, setIsTestingCron] = useState(false);

  const pendingRequests = requests.filter((r) => r.status === 'pending');

  const handleRoleChange = (memberId: string, newRole: UserRole) => {
    const target = members.find((m) => m.id === memberId);
    onAssignRole(memberId, newRole);
    if (target) {
      setRoleUpdateToast({ name: isBn ? target.nameBn : target.nameEn, role: newRole });
      setTimeout(() => setRoleUpdateToast(null), 3500);
    }
  };

  const filteredRoleMembers = members.filter((m) => {
    if (m.isPlaceholder) return false;
    const matchesFilter = roleFilter === 'all' || m.systemRole === roleFilter;
    const q = roleSearchQuery.toLowerCase().trim();
    const matchesQuery = 
      !q || 
      m.nameBn.toLowerCase().includes(q) || 
      m.nameEn.toLowerCase().includes(q) ||
      m.roleBn.toLowerCase().includes(q) ||
      m.roleEn.toLowerCase().includes(q);
    return matchesFilter && matchesQuery;
  });

  const testVercelCron = async () => {
    setIsTestingCron(true);
    try {
      const res = await fetch('/api/cron/check-expiry', {
        headers: {
          Authorization: `Bearer ${settings.cronSecret || 'dev_cron_secret_family_vault_2026'}`,
        },
      });
      const data = await res.json();
      setCronTestResponse(data);
    } catch (e: any) {
      setCronTestResponse({ error: e.message });
    } finally {
      setIsTestingCron(false);
    }
  };

  const roleBadgeStyles: Record<UserRole, { bg: string; text: string; border: string }> = {
    Admin: { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/40' },
    Editor: { bg: 'bg-blue-500/20', text: 'text-blue-300', border: 'border-blue-500/40' },
    Viewer: { bg: 'bg-slate-700/80', text: 'text-slate-300', border: 'border-slate-600' },
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Admin Top Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-950 via-slate-900 to-emerald-950 border border-indigo-500/30 p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold">
              <UserCheck className="w-3.5 h-3.5" />
              <span>{isBn ? 'মারুফের সুরক্ষিত কন্ট্রোল প্যানেল' : "Maruf's Protected Admin Portal"}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {isBn ? 'পারিবারিক অ্যাডমিন ড্যাশবোর্ড ও ভূমিকা নিয়ন্ত্রণ' : 'Admin Control & Role Management'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300">
              {isBn
                ? 'পরিবারের সদস্যদের ভূমিকা (Admin, Editor, Viewer) নির্ধারণ, ফাইল অনুমোদন ও নিরাপত্তা ব্যবস্থাপনা।'
                : 'Assign roles to family members, approve visitor submissions, and manage system security policies.'}
            </p>
          </div>

          <button
            onClick={onOpenAddMemberModal}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-950/40 transition"
          >
            <Plus className="w-4 h-4" />
            <span>{isBn ? 'নতুন সদস্য যুক্ত করুন' : 'Add New Member'}</span>
          </button>
        </div>
      </div>

      {/* Role Update Toast */}
      {roleUpdateToast && (
        <div className="p-4 rounded-2xl bg-emerald-950/90 border border-emerald-500 text-emerald-200 text-xs font-semibold flex items-center justify-between shadow-xl animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span>
              {isBn 
                ? `সফলভাবে সংরক্ষিত! "${roleUpdateToast.name}"-কে "${roleUpdateToast.role}" ভূমিকা দেওয়া হয়েছে।`
                : `Successfully updated! Assigned "${roleUpdateToast.role}" role to "${roleUpdateToast.name}".`}
            </span>
          </div>
          <button onClick={() => setRoleUpdateToast(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Sub Tabs Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs border-b border-slate-800">
        <button
          onClick={() => setActiveSubTab('roles')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'roles'
              ? 'bg-emerald-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>{isBn ? 'রোল এক্সেস কন্ট্রোল (RBAC)' : 'Role Assignment (RBAC)'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('requests')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'requests'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <BellRing className="w-4 h-4" />
          <span>{isBn ? 'অনুরোধ ও ফাইল অনুমোদন' : 'Visitor Approvals'}</span>
          {pendingRequests.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white text-[10px] font-black">
              {pendingRequests.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveSubTab('members')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'members'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>{isBn ? 'সদস্য তালিকা ও সম্পাদনা' : 'Member Directory Control'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('theme')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'theme'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>{isBn ? 'থিম ও প্রাইভেসি সেটিংস' : 'Theme & Privacy'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('cron')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'cron'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <Server className="w-4 h-4" />
          <span>{isBn ? 'Vercel Cron ও মেয়াদ সুরক্ষা' : 'Vercel Cron & Secrets'}</span>
        </button>
      </div>

      {/* Subtab 1: Role-Based Access Control (RBAC) Management */}
      {activeSubTab === 'roles' && (
        <div className="space-y-6">
          
          {/* Roles Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Admin Card */}
            <div className="p-5 rounded-3xl bg-slate-850 border border-emerald-500/40 shadow space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Admin (অ্যাডমিন)
                </span>
                <span className="text-xs text-slate-400 font-semibold">
                  {members.filter((m) => m.systemRole === 'Admin').length} {isBn ? 'জন' : 'User(s)'}
                </span>
              </div>
              <h4 className="font-extrabold text-sm text-white">
                {isBn ? 'পূর্ণ নিয়ন্ত্রণাধিকার (Full Control)' : 'Full Control Authority'}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isBn
                  ? 'মারুফের জন্য নির্ধারিত। সদস্য যোগ, পরিবর্তন বা মুছে ফেলা, অন্যান্য সদস্যদের ভূমিকা নির্ধারণ, আত্মীয়দের ফাইল অনুমোদন ও ক্রন সিকিউরিটি নিয়ন্ত্রণ।'
                  : 'Full control: Add/remove members, assign roles to family, approve visitor submissions, manage vault security.'}
              </p>
            </div>

            {/* Editor Card */}
            <div className="p-5 rounded-3xl bg-slate-850 border border-blue-500/40 shadow space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  Editor (এডিটর)
                </span>
                <span className="text-xs text-slate-400 font-semibold">
                  {members.filter((m) => m.systemRole === 'Editor').length} {isBn ? 'জন' : 'User(s)'}
                </span>
              </div>
              <h4 className="font-extrabold text-sm text-white">
                {isBn ? 'যোগ ও সম্পাদনা (Add & Edit)' : 'Add & Edit Rights'}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isBn
                  ? 'নতুন দলিল ও সনদ ভল্টে আপলোড করতে পারবেন এবং সদস্যদের ব্যক্তিগত প্রোফাইল তথ্য সম্পাদনা করতে পারবেন। তবে কাউকে ভূমিকা দিতে পারবেন না।'
                  : 'Can add/edit vault documents and edit member profiles. Cannot assign roles or delete members.'}
              </p>
            </div>

            {/* Viewer Card */}
            <div className="p-5 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-slate-700 text-slate-300">
                  Viewer (ভিউয়ার)
                </span>
                <span className="text-xs text-slate-400 font-semibold">
                  {members.filter((m) => m.systemRole === 'Viewer' && !m.isPlaceholder).length} {isBn ? 'জন' : 'User(s)'}
                </span>
              </div>
              <h4 className="font-extrabold text-sm text-white">
                {isBn ? 'শুধুমাত্র প্রদর্শন (View Only)' : 'Read-Only Viewing'}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isBn
                  ? 'শুধুমাত্র সংরক্ষিত দলিল, পারিবারিক প্রোফাইল, উত্তরাধিকার ক্যালকুলেটর ও ই-নামজারি সহায়িকা দেখতে পারবেন। কোনো পরিবর্তন করতে পারবেন না।'
                  : 'Can only view vault records, inheritance calculator, and family directory. Cannot add, edit, or delete.'}
              </p>
            </div>

          </div>

          {/* Role Assignment Controls for Maruf */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-700/60 pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <UserCog className="w-5 h-5 text-emerald-400" />
                  <span>{isBn ? 'সদস্যদের ভূমিকা নির্ধারণ প্যানেল' : 'Member Role Assignment Mechanism'}</span>
                </h3>
                <p className="text-xs text-slate-400">
                  {isBn 
                    ? 'মারুফ হিসেবে আপনি যেকোনো সদস্যের ভূমিকা (Admin, Editor, Viewer) পরিবর্তন ও সেভ করতে পারেন।' 
                    : 'As Maruf, select and update the role permission level for each family member.'}
                </p>
              </div>

              {/* Filter by Role */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-medium">{isBn ? 'ফিল্টার:' : 'Filter:'}</span>
                <select
                  value={roleFilter}
                  onChange={(e: any) => setRoleFilter(e.target.value)}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">{isBn ? 'সকল সদস্য' : 'All Roles'}</option>
                  <option value="Admin">Admin</option>
                  <option value="Editor">Editor</option>
                  <option value="Viewer">Viewer</option>
                </select>
              </div>
            </div>

            {/* Member Role Assignment Cards / Table */}
            <div className="space-y-2.5">
              {filteredRoleMembers.map((member) => {
                const isMaruf = member.id === 'maruf';

                return (
                  <div
                    key={member.id}
                    className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                      isMaruf
                        ? 'bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border-emerald-500/50 ring-1 ring-emerald-500/20'
                        : 'bg-slate-900/80 border-slate-700/70 hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold text-sm shadow ${member.avatarColor}`}>
                        {member.nameBn.slice(0, 2)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-sm text-white">
                            {isBn ? member.nameBn : member.nameEn}
                          </h4>
                          {isMaruf && (
                            <span className="text-[10px] font-black px-2 py-0.2 rounded-full bg-emerald-400 text-slate-950">
                              {isBn ? 'মূল অ্যাডমিন' : 'Primary Admin'}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400">
                          {isBn ? member.roleBn : member.roleEn} {member.phone ? `• ${member.phone}` : ''}
                        </p>
                      </div>
                    </div>

                    {/* Role Selector & Action */}
                    <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                      <div className="text-right hidden md:block">
                        <span className="text-[10px] text-slate-400 block font-medium">
                          {isBn ? 'নির্ধারিত ভূমিকা' : 'Current Role'}
                        </span>
                        <span className={`text-xs font-bold ${roleBadgeStyles[member.systemRole].text}`}>
                          {member.systemRole}
                        </span>
                      </div>

                      {/* Mechanism for Maruf to assign role */}
                      <select
                        value={member.systemRole}
                        onChange={(e) => handleRoleChange(member.id, e.target.value as UserRole)}
                        disabled={isMaruf} // Maruf stays Primary Admin
                        className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition outline-none cursor-pointer ${
                          roleBadgeStyles[member.systemRole].bg
                        } ${roleBadgeStyles[member.systemRole].border} ${roleBadgeStyles[member.systemRole].text} ${
                          isMaruf ? 'opacity-80 cursor-not-allowed' : 'hover:scale-102 focus:ring-2 focus:ring-emerald-500'
                        }`}
                      >
                        <option value="Admin" className="bg-slate-900 text-emerald-300 font-bold">Admin (সম্পূর্ণ নিয়ন্ত্রণ)</option>
                        <option value="Editor" className="bg-slate-900 text-blue-300 font-bold">Editor (ডকুমেন্ট ও প্রোফাইল যোগ/সম্পাদনা)</option>
                        <option value="Viewer" className="bg-slate-900 text-slate-300 font-bold">Viewer (শুধুমাত্র প্রদর্শন)</option>
                      </select>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Permission Matrix Comparison Table */}
            <div className="pt-6 border-t border-slate-700/60 space-y-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'ভূমিকাভিত্তিক অনুমতি তুলনামূলক সারণী (Permission Matrix)' : 'Role Permission Matrix'}</span>
              </h4>

              <div className="overflow-x-auto rounded-2xl border border-slate-700">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/90 text-slate-200 border-b border-slate-700 uppercase tracking-wider text-[11px]">
                    <tr>
                      <th className="p-3.5 font-bold">{isBn ? 'ফিচার / কার্যক্রম' : 'Feature / Action'}</th>
                      <th className="p-3.5 font-bold text-emerald-400 text-center">Admin</th>
                      <th className="p-3.5 font-bold text-blue-400 text-center">Editor</th>
                      <th className="p-3.5 font-bold text-slate-400 text-center">Viewer</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 bg-slate-900/40">
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'ভল্ট ও পারিবারিক ডিরেক্টরি দেখা (View Vault & Profiles)' : 'View Vault & Profiles'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'নতুন দলিল ও সনদ ভল্টে যোগ করা (Add Documents)' : 'Add Vault Documents'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'সদস্যদের প্রোফাইল তথ্য সম্পাদনা (Edit Member Profiles)' : 'Edit Member Profiles'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'সদস্য যোগ ও মুছে ফেলা (Add / Delete Members)' : 'Add / Delete Members'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'ভূমিকা নির্ধারণ ও RBAC পরিচালনা (Assign Roles)' : 'Assign Roles (RBAC)'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'আত্মীয়দের ফাইল অনুমোদন (Approve Visitor Requests)' : 'Approve Visitor Requests'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'Vercel Cron ও সিস্টেম সেটিংস নিয়ন্ত্রণ (System Config & Cron)' : 'System Config & Cron'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* Subtab 2: Visitor Query & Document Upload Approvals */}
      {activeSubTab === 'requests' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-850 border border-slate-700 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <FileCheck2 className="w-4 h-4 text-emerald-400" />
              <span>
                {isBn 
                  ? `অনুমোদনের অপেক্ষায় আবেদন (${pendingRequests.length}টি)` 
                  : `Pending Approvals Queue (${pendingRequests.length})`}
              </span>
            </h3>
            <p className="text-xs text-slate-400 hidden sm:block">
              {isBn 
                ? 'আত্মীয়দের প্রেরিত ফাইল বা তথ্য মারুফের অনুমোদন ছাড়া ডিরেক্টরিতে দৃশ্যমান হবে না।' 
                : 'Submissions remain private until approved by Maruf.'}
            </p>
          </div>

          {pendingRequests.length > 0 ? (
            <div className="space-y-3">
              {pendingRequests.map((req) => (
                <div
                  key={req.id}
                  className="p-5 rounded-2xl bg-slate-850 border border-slate-700 hover:border-slate-600 shadow space-y-3"
                >
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        {req.requestType === 'document_upload' ? (isBn ? 'দলিল আপলোড' : 'Document Upload') : (isBn ? 'তথ্য পরিবর্তন' : 'Info Update')}
                      </span>
                      <h4 className="font-bold text-sm text-white mt-1">{req.title}</h4>
                      <p className="text-xs text-slate-300">
                        {isBn ? 'আবেদনকারী:' : 'Submitter:'} <span className="font-semibold text-white">{req.submitterName}</span> ({req.submitterPhone}) • {req.relationClaimBn}
                      </p>
                    </div>

                    <span className="text-[11px] text-slate-400">{req.submittedAt}</span>
                  </div>

                  <p className="text-xs text-slate-300 bg-slate-900/70 p-3 rounded-xl border border-slate-800 leading-relaxed">
                    "{req.description}"
                  </p>

                  <div className="flex items-center justify-end gap-2 pt-2">
                    <button
                      onClick={() => onRejectRequest(req.id)}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950 text-rose-300 border border-slate-700 hover:border-rose-700 text-xs font-semibold transition"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>{isBn ? 'প্রত্যাখ্যান করুন' : 'Reject'}</span>
                    </button>

                    <button
                      onClick={() => onApproveRequest(req.id)}
                      className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow transition"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{isBn ? 'অনুমোদন দিন' : 'Approve & Publish'}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-2xl bg-slate-850 border border-dashed border-slate-700 text-center space-y-2">
              <Check className="w-8 h-8 text-emerald-400 mx-auto" />
              <p className="text-xs text-slate-300 font-semibold">
                {isBn ? 'বর্তমানে কোনো পেন্ডিং আবেদন বা ফাইল নেই।' : 'No pending approval requests.'}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Subtab 3: Member Directory Management */}
      {activeSubTab === 'members' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-850 border border-slate-700 flex justify-between items-center">
            <h3 className="text-sm font-bold text-white">
              {isBn ? `পরিবারের সকল সদস্য (${members.length} জন)` : `All Family Members (${members.length})`}
            </h3>
            <button
              onClick={onOpenAddMemberModal}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isBn ? 'নতুন সদস্য' : 'Add Member'}</span>
            </button>
          </div>

          <div className="space-y-2">
            {members.map((m) => (
              <div
                key={m.id}
                className="p-3.5 rounded-2xl bg-slate-850 border border-slate-700/70 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${m.avatarColor}`}>
                    {m.nameBn.slice(0, 2)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-white">{isBn ? m.nameBn : m.nameEn}</h4>
                      <span className={`px-2 py-0.2 rounded-full text-[10px] font-bold border ${roleBadgeStyles[m.systemRole].bg} ${roleBadgeStyles[m.systemRole].text} ${roleBadgeStyles[m.systemRole].border}`}>
                        {m.systemRole}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {isBn ? m.roleBn : m.roleEn} {m.phone ? `• ${m.phone}` : ''}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {m.id !== 'maruf' && m.id !== 'barek_bhuyan' && (
                    <button
                      onClick={() => onDeleteMember(m.id)}
                      title={isBn ? 'মুছে ফেলুন' : 'Delete Member'}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-700 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Subtab 4: Theme & Privacy Settings */}
      {activeSubTab === 'theme' && (
        <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 space-y-6">
          <h3 className="text-sm font-bold text-white border-b border-slate-700 pb-3">
            {isBn ? 'থিম কাস্টমাইজেশন ও গোপনীয়তা কন্ট্রোল' : 'Theme Customization & Privacy Settings'}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'প্রাইমারি কালার অ্যাকসেন্ট' : 'Primary Color Accent'}
              </label>
              <select
                value={settings.accentColor}
                onChange={(e: any) => onUpdateSettings({ ...settings, accentColor: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs outline-none"
              >
                <option value="emerald">{isBn ? 'এমারেল্ড গ্রীন (আইনি ও সম্পত্তি)' : 'Emerald Legal Green'}</option>
                <option value="sapphire">{isBn ? 'রয়্যাল স্যাফায়ার ব্লু' : 'Royal Sapphire Blue'}</option>
                <option value="amber">{isBn ? 'ওয়ার্ম গোল্ড ও অ্যাম্বার' : 'Warm Gold & Amber'}</option>
                <option value="slate">{isBn ? 'ক্লাসিক স্লট ডার্ক' : 'Classic Slate Dark'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'লেআউট ডেনসিটি' : 'Layout Density'}
              </label>
              <select
                value={settings.layoutDensity}
                onChange={(e: any) => onUpdateSettings({ ...settings, layoutDensity: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs outline-none"
              >
                <option value="comfortable">{isBn ? 'কম্ফোর্টেবল (প্রস্তাবিত)' : 'Comfortable (Recommended)'}</option>
                <option value="compact">{isBn ? 'কম্প্যাক্ট (ঘন বিন্যাস)' : 'Compact'}</option>
                <option value="spacious">{isBn ? 'স্পেসিয়াস (প্রশস্ত)' : 'Spacious'}</option>
              </select>
            </div>
          </div>

          {/* Privacy Toggle */}
          <div className="pt-4 border-t border-slate-700/60 flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-white">
                {isBn ? 'অতিথিদের জন্য সংবেদনশীল তথ্য গোপন রাখুন' : 'Hide Sensitive Data for Guests'}
              </h4>
              <p className="text-[11px] text-slate-400">
                {isBn ? 'এনআইডি নম্বর ও ব্যক্তিগত ফোন নম্বর শুধুমাত্র অ্যাডমিন দেখলে দৃশ্যমান হবে।' : 'Hide NIDs and phones for non-admin viewers.'}
              </p>
            </div>
            <button
              onClick={() => onUpdateSettings({ ...settings, hideSensitiveDataForGuests: !settings.hideSensitiveDataForGuests })}
              className={`p-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition ${
                settings.hideSensitiveDataForGuests
                  ? 'bg-emerald-600 text-white border-emerald-500'
                  : 'bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              {settings.hideSensitiveDataForGuests ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              <span>{settings.hideSensitiveDataForGuests ? (isBn ? 'গোপন চালু' : 'Hidden') : (isBn ? 'উন্মুক্ত' : 'Visible')}</span>
            </button>
          </div>
        </div>
      )}

      {/* Subtab 5: Vercel Cron & Secrets Configuration */}
      {activeSubTab === 'cron' && (
        <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 space-y-6">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Server className="w-4 h-4 text-emerald-400" />
              <span>{isBn ? 'Vercel Cron ব্যাকগ্রাউন্ড এক্সপায়ারি জব ও সিকিউরিটি' : 'Vercel Cron Expiry Job Security'}</span>
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {isBn 
                ? 'সার্ভারলেস পরিবেশে অননুমোদিত ইউজার যেন বারবার এক্সপায়ারি নোটিফিকেশন ট্রিগার করতে না পারে, সেজন্য Bearer CRON_SECRET অথরাইজেশন হেডার প্রয়োগ করা হয়েছে।'
                : 'Securing serverless cron jobs to prevent unauthorized triggering and email spam via Bearer Token authentication.'}
            </p>
          </div>

          {/* Configuration Code Preview */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-[11px] font-mono font-bold text-emerald-400">vercel.json configuration:</span>
            <pre className="text-[11px] font-mono text-slate-300 bg-slate-950 p-3 rounded-xl overflow-x-auto">
{`{
  "crons": [
    {
      "path": "/api/cron/check-expiry",
      "schedule": "0 0 * * *"
    }
  ]
}`}
            </pre>
          </div>

          <div className="space-y-3">
            <label className="block text-xs font-semibold text-slate-300">
              {isBn ? 'এনভায়রনমেন্ট সিক্রেট টোকেন (CRON_SECRET)' : 'CRON_SECRET Environment Token'}
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={settings.cronSecret}
                onChange={(e) => onUpdateSettings({ ...settings, cronSecret: e.target.value })}
                className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
              />
              <button
                onClick={testVercelCron}
                disabled={isTestingCron}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow transition"
              >
                {isTestingCron ? (isBn ? 'পরীক্ষা চলছে...' : 'Testing...') : (isBn ? 'অথরাইজেশন টেস্ট করুন' : 'Test Secret Auth')}
              </button>
            </div>
          </div>

          {cronTestResponse && (
            <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/30 text-xs font-mono space-y-1">
              <span className="text-emerald-400 font-bold block">{isBn ? 'সার্ভার রেসপন্স:' : 'Server Response:'}</span>
              <pre className="text-slate-300 text-[11px] overflow-x-auto whitespace-pre-wrap">
                {JSON.stringify(cronTestResponse, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
