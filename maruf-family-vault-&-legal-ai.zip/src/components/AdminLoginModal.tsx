import React, { useState } from 'react';
import { Lock, X, ShieldCheck, KeyRound, Sparkles } from 'lucide-react';
import { Language } from '../types/family';

interface AdminLoginModalProps {
  language: Language;
  onClose: () => void;
  onSuccessLogin: () => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  language,
  onClose,
  onSuccessLogin,
}) => {
  const isBn = language === 'bn';
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Accept standard maruf pin or default 'maruf123'
    if (password.toLowerCase() === 'maruf123' || password === '1985' || password.toLowerCase() === 'maruf') {
      onSuccessLogin();
      onClose();
    } else {
      setError(true);
    }
  };

  const handleQuickDemo = () => {
    onSuccessLogin();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-700/80 p-6 sm:p-8 space-y-5 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/40 flex items-center justify-center mx-auto shadow-md">
            <KeyRound className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-extrabold text-white">
            {isBn ? 'মারুফের অ্যাডমিন লগইন' : "Maruf's Admin Login"}
          </h3>
          <p className="text-xs text-slate-400">
            {isBn 
              ? 'পারিবারিক সদস্য পরিবর্তন, ফাইল অনুমোদন ও সেটিংস নিয়ন্ত্রণের জন্য পিন প্রবেশ করান।' 
              : 'Enter admin passphrase or PIN to access editing and approvals.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isBn ? 'অ্যাডমিন পাসওয়ার্ড বা পিন' : 'Admin Passphrase or PIN'}
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError(false);
              }}
              placeholder={isBn ? 'পাসওয়ার্ড লিখুন (যেমন: maruf123)' : 'Enter password (e.g. maruf123)'}
              className="w-full px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
              autoFocus
            />
            {error && (
              <p className="text-xs text-rose-400 mt-1">
                {isBn ? 'ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিন।' : 'Incorrect passphrase! Please try again.'}
              </p>
            )}
            <p className="text-[11px] text-slate-500 mt-1">
              {isBn ? 'ডিফল্ট পাসওয়ার্ড: ' : 'Default passphrase: '}
              <code className="text-indigo-400">maruf123</code>
            </p>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-indigo-950/40 transition"
          >
            {isBn ? 'লগইন সম্পন্ন করুন' : 'Unlock Admin Portal'}
          </button>
        </form>

        <div className="pt-3 border-t border-slate-800">
          <button
            type="button"
            onClick={handleQuickDemo}
            className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>{isBn ? '১-ক্লিক দ্রুত অ্যাডমিন অ্যাক্সেস (টেস্টিং)' : '1-Click Fast Admin Access (Demo)'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
