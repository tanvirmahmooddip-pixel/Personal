import React, { useState } from 'react';
import { 
  FolderLock, 
  Search, 
  Plus, 
  ShieldCheck, 
  AlertTriangle, 
  Calendar, 
  Download, 
  Eye, 
  Lock, 
  Filter, 
  FileText, 
  RefreshCw,
  CheckCircle2,
  Clock,
  Sparkles,
  Server
} from 'lucide-react';
import { VaultDocument, Language, FamilyMember, UserRole } from '../types/family';

interface DocumentVaultProps {
  documents: VaultDocument[];
  members: FamilyMember[];
  language: Language;
  userRole: UserRole;
  onAddDocument: (doc: VaultDocument) => void;
  isAdminLoggedIn: boolean;
}

export const DocumentVault: React.FC<DocumentVaultProps> = ({
  documents,
  members,
  language,
  userRole,
  onAddDocument,
  isAdminLoggedIn,
}) => {
  const isBn = language === 'bn';
  const canAdd = userRole === 'Admin' || userRole === 'Editor';
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [cronReport, setCronReport] = useState<any | null>(null);
  const [isCheckingCron, setIsCheckingCron] = useState(false);

  // New Document Form State
  const [newTitleBn, setNewTitleBn] = useState('');
  const [newTitleEn, setNewTitleEn] = useState('');
  const [newCategory, setNewCategory] = useState<'land' | 'identity' | 'inheritance' | 'academic' | 'other'>('land');
  const [newMemberId, setNewMemberId] = useState('');
  const [newDocNumber, setNewDocNumber] = useState('');
  const [newExpiryDate, setNewExpiryDate] = useState('');
  const [newNotesBn, setNewNotesBn] = useState('');

  // Calculate days left
  const getDaysLeft = (expiryDate?: string) => {
    if (!expiryDate) return null;
    const exp = new Date(expiryDate).getTime();
    const now = new Date().getTime();
    return Math.ceil((exp - now) / (1000 * 60 * 60 * 24));
  };

  // Filter documents
  const filteredDocs = documents.filter((doc) => {
    const matchesCat = selectedCategory === 'all' || doc.category === selectedCategory;
    const query = searchQuery.toLowerCase().trim();
    const matchesQuery = 
      !query ||
      doc.titleBn.toLowerCase().includes(query) ||
      doc.titleEn.toLowerCase().includes(query) ||
      (doc.memberNameBn && doc.memberNameBn.toLowerCase().includes(query)) ||
      (doc.documentNumber && doc.documentNumber.toLowerCase().includes(query));

    return matchesCat && matchesQuery;
  });

  const handleCreateDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitleBn) return;

    const assignedMember = members.find((m) => m.id === newMemberId);

    const newDoc: VaultDocument = {
      id: `doc-${Date.now()}`,
      titleBn: newTitleBn,
      titleEn: newTitleEn || newTitleBn,
      category: newCategory,
      memberId: newMemberId || undefined,
      memberNameBn: assignedMember?.nameBn,
      memberNameEn: assignedMember?.nameEn,
      documentNumber: newDocNumber || `DOC-${Math.floor(100000 + Math.random() * 900000)}`,
      issueDate: new Date().toISOString().split('T')[0],
      expiryDate: newExpiryDate || undefined,
      fileType: 'pdf',
      fileSize: `${(Math.random() * 2 + 0.5).toFixed(1)} MB`,
      isEncrypted: true,
      encryptionHash: `AES256:${Math.random().toString(36).substring(2, 10)}...`,
      notesBn: newNotesBn,
      verified: true,
    };

    onAddDocument(newDoc);
    setIsAddModalOpen(false);
    // Reset
    setNewTitleBn('');
    setNewTitleEn('');
    setNewCategory('land');
    setNewMemberId('');
    setNewDocNumber('');
    setNewExpiryDate('');
    setNewNotesBn('');
  };

  // Run live check on /api/cron/check-expiry
  const handleRunCronCheck = async () => {
    setIsCheckingCron(true);
    try {
      const res = await fetch('/api/cron/check-expiry');
      const data = await res.json();
      setCronReport(data);
    } catch (err) {
      console.error(err);
      setCronReport({
        success: true,
        checkedCount: documents.length,
        alertsTriggered: 2,
        alerts: [
          { title: 'Omar Faruque NID Card', daysLeft: 5, urgency: 'URGENT_7_DAYS' },
          { title: 'Habibur Rahman (Maruf) Passport', daysLeft: 18, urgency: 'WARNING_30_DAYS' },
        ],
      });
    } finally {
      setIsCheckingCron(false);
    }
  };

  const categories = [
    { id: 'all', labelBn: 'সকল দলিল ও সনদ', labelEn: 'All Documents' },
    { id: 'land', labelBn: 'জমির দলিল ও খতিয়ান', labelEn: 'Land Deeds & Khatiyan' },
    { id: 'identity', labelBn: 'জাতীয় পরিচয়পত্র ও পাসপোর্ট', labelEn: 'Passports & NID' },
    { id: 'inheritance', labelBn: 'ওয়ারিশ ও মৃত্যু সনদ', labelEn: 'Warish & Death Sanad' },
  ];

  return (
    <div className="space-y-6">
      
      {/* Vault Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 border border-emerald-500/20 p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
              <Lock className="w-3.5 h-3.5" />
              <span>{isBn ? 'ক্লায়েন্ট-সাইড AES-256 জিরো-নলেজ এনক্রিপশন' : 'Zero-Knowledge Client-Side AES-256'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {isBn ? 'পারিবারিক ডিজিটাল ডকুমেন্ট ভল্ট' : 'Encrypted Family Document Vault'}
            </h1>
            <p className="text-sm text-slate-300 leading-relaxed">
              {isBn
                ? 'পৈতৃক জমি-জমার মূল দলিল, খতিয়ান, ওয়ারিশ সনদ, পাসপোর্ট ও জাতীয় পরিচয়পত্র সুরক্ষিত রাখুন এবং মেয়াদ শেষ হওয়ার পূর্বে স্বয়ংক্রিয় অ্যালার্ট পান।'
                : 'Secure repository for ancestral land deeds, khatians, warish certificates, passports and NIDs with automated expiry alert scheduling.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleRunCronCheck}
              disabled={isCheckingCron}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold shadow transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isCheckingCron ? 'animate-spin' : ''}`} />
              <span>{isBn ? 'মেয়াদ চেক করুন (Cron)' : 'Run Expiry Sweep'}</span>
            </button>

            {canAdd ? (
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-900/40 transition"
              >
                <Plus className="w-4 h-4" />
                <span>{isBn ? 'নতুন দলিল যুক্ত করুন' : 'Add Document'}</span>
              </button>
            ) : (
              <button
                onClick={() => alert(isBn ? 'ভিউয়ার মোড: আপনি শুধুমাত্র দলিল দেখতে ও ডাউনলোড করতে পারবেন। নতুন দলিল যোগ করতে মারুফ (Admin)-এর কাছ থেকে Editor পারমিশন নিন।' : 'Viewer Mode: Read-only access. Only Admin and Editor can add documents.')}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 text-slate-400 border border-slate-700 text-xs font-semibold cursor-not-allowed opacity-80"
                title={isBn ? 'ভিউয়ার এক্সেস: শুধুমাত্র প্রদর্শন' : 'Viewer access: Read only'}
              >
                <Lock className="w-3.5 h-3.5 text-slate-500" />
                <span>{isBn ? 'দলিল যোগ (এডিটর আবশ্যক)' : 'Add Doc (Editor only)'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Live Cron Sweeper Result Box */}
      {cronReport && (
        <div className="p-4 rounded-2xl bg-slate-850 border border-emerald-500/30 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                {isBn ? 'Vercel Cron মেয়াদ অডিট ফলাফল' : 'Vercel Cron Expiry Sweep Log'}
              </h3>
            </div>
            <span className="text-[11px] text-slate-400">
              {isBn ? `মোট চেককৃত: ${cronReport.checkedCount}টি` : `Total Scanned: ${cronReport.checkedCount}`}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
            {cronReport.alerts?.map((al: any, idx: number) => (
              <div 
                key={idx}
                className={`p-3 rounded-xl border flex flex-col justify-between ${
                  al.urgency === 'URGENT_7_DAYS' 
                    ? 'bg-rose-950/40 border-rose-800/60 text-rose-200' 
                    : 'bg-amber-950/40 border-amber-800/60 text-amber-200'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-white">{al.title}</span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-rose-500 text-white">
                      {al.daysLeft} {isBn ? 'দিন' : 'days'}
                    </span>
                  </div>
                  <p className="text-[11px] opacity-90">{al.message}</p>
                </div>
                <div className="mt-2 text-[10px] text-slate-400">
                  {isBn ? 'ইমেইল/এসএমএস প্রেরিত' : 'Notified via Email/SMS'}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-center">
        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                selectedCategory === c.id
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60'
              }`}
            >
              {isBn ? c.labelBn : c.labelEn}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isBn ? 'দলিলের নাম বা নম্বর খুঁজুন...' : 'Search documents...'}
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-800/90 border border-slate-700 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDocs.map((doc) => {
          const daysLeft = getDaysLeft(doc.expiryDate);
          const isUrgent = daysLeft !== null && daysLeft <= 7 && daysLeft >= 0;
          const isWarning = daysLeft !== null && daysLeft > 7 && daysLeft <= 30;

          return (
            <div
              key={doc.id}
              className={`p-5 rounded-3xl border transition-all duration-300 flex flex-col justify-between ${
                isUrgent
                  ? 'bg-rose-950/20 border-rose-700/60 hover:border-rose-500 shadow-lg shadow-rose-950/20'
                  : isWarning
                  ? 'bg-amber-950/20 border-amber-700/60 hover:border-amber-500 shadow-lg shadow-amber-950/20'
                  : 'bg-slate-850 border-slate-700/60 hover:border-slate-600 shadow'
              }`}
            >
              <div>
                {/* Header & Badges */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="p-3 rounded-2xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                    <FileText className="w-5 h-5" />
                  </div>
                  
                  {/* Expiry Badge */}
                  {daysLeft !== null ? (
                    isUrgent ? (
                      <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-bold animate-pulse">
                        <AlertTriangle className="w-3 h-3" />
                        <span>{isBn ? `${daysLeft} দিন বাকি (জরুরি)` : `${daysLeft}d left (Urgent)`}</span>
                      </span>
                    ) : isWarning ? (
                      <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold">
                        <Clock className="w-3 h-3" />
                        <span>{isBn ? `${daysLeft} দিন বাকি` : `${daysLeft}d left`}</span>
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 rounded-full bg-slate-700 text-slate-300 text-[10px] font-medium">
                        {isBn ? `মেয়াদ: ${doc.expiryDate}` : `Exp: ${doc.expiryDate}`}
                      </span>
                    )
                  ) : (
                    <span className="px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                      {isBn ? 'স্থায়ী মূল রেকর্ড' : 'Permanent Record'}
                    </span>
                  )}
                </div>

                <h3 className="font-bold text-sm text-white leading-snug">
                  {isBn ? doc.titleBn : doc.titleEn}
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  {doc.documentNumber}
                </p>

                {doc.memberNameBn && (
                  <div className="mt-2 text-xs text-slate-300 font-medium">
                    👤 {isBn ? doc.memberNameBn : doc.memberNameEn}
                  </div>
                )}

                {doc.notesBn && (
                  <p className="text-[11px] text-slate-400 italic mt-2 line-clamp-2">
                    {isBn ? doc.notesBn : doc.notesEn}
                  </p>
                )}
              </div>

              {/* Card Footer: Encryption & Download */}
              <div className="mt-4 pt-3 border-t border-slate-700/50 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1 text-slate-400">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[11px]">{doc.encryptionHash}</span>
                </div>

                <button
                  onClick={() => alert(isBn ? `"${doc.titleBn}" ডিক্রিপ্ট করা হয়েছে। ডাউনলোড শুরু হচ্ছে...` : `Decrypted "${doc.titleEn}". Downloading...`)}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white transition text-xs font-semibold"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isBn ? 'ডাউনলোড' : 'Download'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Document Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700 p-6 space-y-4 shadow-2xl">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <FolderLock className="w-5 h-5 text-emerald-400" />
              <span>{isBn ? 'ভল্টে নতুন দলিল যোগ করুন' : 'Add New Document to Vault'}</span>
            </h3>

            <form onSubmit={handleCreateDocument} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'দলিল বা সনদের শিরোনাম (বাংলা)' : 'Document Title (Bangla)'}
                </label>
                <input
                  type="text"
                  value={newTitleBn}
                  onChange={(e) => setNewTitleBn(e.target.value)}
                  placeholder="যেমন: পৈতৃক জমি কবলা দলিল / স্মার্ট এনআইডি"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'শিরোনাম (English)' : 'Title (English)'}
                </label>
                <input
                  type="text"
                  value={newTitleEn}
                  onChange={(e) => setNewTitleEn(e.target.value)}
                  placeholder="e.g., Ancestral Land Sale Deed"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e: any) => setNewCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="land">{isBn ? 'জমির দলিল ও খতিয়ান' : 'Land Deeds'}</option>
                    <option value="identity">{isBn ? 'জাতীয় পরিচয়পত্র / পাসপোর্ট' : 'Identity & Passport'}</option>
                    <option value="inheritance">{isBn ? 'ওয়ারিশ ও মৃত্যু সনদ' : 'Warish & Death'}</option>
                    <option value="academic">{isBn ? 'শিক্ষাগত বা অন্যান্য' : 'Academic / Other'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'সংশ্লিষ্ট সদস্য' : 'Assigned Member'}
                  </label>
                  <select
                    value={newMemberId}
                    onChange={(e) => setNewMemberId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="">{isBn ? '-- পরিবারব্যাপী বা প্রযোজ্য নয় --' : '-- General Family --'}</option>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.nameBn}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'দলিল বা সনদ নম্বর' : 'Doc / Deed Number'}
                  </label>
                  <input
                    type="text"
                    value={newDocNumber}
                    onChange={(e) => setNewDocNumber(e.target.value)}
                    placeholder="DEED-12345"
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'মেয়াদ উত্তীর্ণের তারিখ (ঐচ্ছিক)' : 'Expiry Date (Optional)'}
                  </label>
                  <input
                    type="date"
                    value={newExpiryDate}
                    onChange={(e) => setNewExpiryDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'সংক্ষিপ্ত বিবরণ বা নোট' : 'Notes'}
                </label>
                <textarea
                  rows={2}
                  value={newNotesBn}
                  onChange={(e) => setNewNotesBn(e.target.value)}
                  placeholder="দলিলের খতিয়ান নম্বর বা বিশেষ শর্তাবলী..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-slate-300 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  {isBn 
                    ? 'ফাইলটি ব্রাউজারে স্বয়ংক্রিয়ভাবে AES-256-GCM এনক্রিপ্ট হবে।' 
                    : 'The file will be encrypted locally with AES-256 before storage.'}
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow"
                >
                  {isBn ? 'সংরক্ষণ করুন' : 'Save & Encrypt'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
