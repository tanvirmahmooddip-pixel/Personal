import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Heart, 
  Phone, 
  FileCheck2, 
  Edit3, 
  Sparkles, 
  UserPlus, 
  ShieldCheck, 
  ChevronRight,
  Info,
  CheckCircle2,
  Shield,
  Lock
} from 'lucide-react';
import { FamilyMember, Language, BranchCategory, AdminSettings, UserRole } from '../types/family';

interface FamilyDirectoryProps {
  members: FamilyMember[];
  language: Language;
  userRole: UserRole;
  onSelectMember: (member: FamilyMember) => void;
  onQuickUpdatePlaceholder: (id: string, newNameBn: string, newNameEn: string) => void;
  onOpenAddMemberModal: () => void;
  onOpenVisitorRequestModal: () => void;
  isAdminLoggedIn: boolean;
  settings: AdminSettings;
}

export const FamilyDirectory: React.FC<FamilyDirectoryProps> = ({
  members,
  language,
  userRole,
  onSelectMember,
  onQuickUpdatePlaceholder,
  onOpenAddMemberModal,
  onOpenVisitorRequestModal,
  isAdminLoggedIn,
  settings,
}) => {
  const isBn = language === 'bn';
  const [selectedBranch, setSelectedBranch] = useState<BranchCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingPlaceholderId, setEditingPlaceholderId] = useState<string | null>(null);
  const [placeholderInputBn, setPlaceholderInputBn] = useState('');
  const [placeholderInputEn, setPlaceholderInputEn] = useState('');

  const canEdit = userRole === 'Admin' || userRole === 'Editor';
  const canAdd = userRole === 'Admin';

  // Filter members
  const filteredMembers = members.filter((member) => {
    const matchesBranch = selectedBranch === 'all' || member.branch === selectedBranch;
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch = 
      !query ||
      member.nameBn.toLowerCase().includes(query) ||
      member.nameEn.toLowerCase().includes(query) ||
      member.roleBn.toLowerCase().includes(query) ||
      member.roleEn.toLowerCase().includes(query) ||
      (member.phone && member.phone.includes(query)) ||
      (member.bloodGroup && member.bloodGroup.toLowerCase().includes(query));

    return matchesBranch && matchesSearch;
  });

  const handleStartEditPlaceholder = (member: FamilyMember, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!canEdit) {
      alert(isBn ? 'দুঃখিত! শুধুমাত্র অ্যাডমিন বা এডিটর প্রোফাইল এডিট করতে পারেন।' : 'Only Admin or Editor can edit profiles.');
      return;
    }
    setEditingPlaceholderId(member.id);
    setPlaceholderInputBn(member.nameBn.startsWith('[') ? '' : member.nameBn);
    setPlaceholderInputEn(member.nameEn.startsWith('[') ? '' : member.nameEn);
  };

  const handleSavePlaceholder = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!placeholderInputBn.trim()) return;
    onQuickUpdatePlaceholder(
      id, 
      placeholderInputBn.trim(), 
      placeholderInputEn.trim() || placeholderInputBn.trim()
    );
    setEditingPlaceholderId(null);
  };

  const branches: { id: BranchCategory; labelBn: string; labelEn: string; iconEmoji: string }[] = [
    { id: 'all', labelBn: 'সকল সদস্য', labelEn: 'All Members', iconEmoji: '👨‍👩‍👧‍👦' },
    { id: 'parents', labelBn: 'পিতা ও মাতা', labelEn: 'Parents', iconEmoji: '👑' },
    { id: 'omar_faruque', labelBn: 'বড় ভাই ওমর ফারুক', labelEn: 'Omar Faruque Branch', iconEmoji: '💼' },
    { id: 'abdul_kader', labelBn: 'মেজো ভাই আব্দুল কাদের', labelEn: 'Abdul Kader Branch', iconEmoji: '🌍' },
    { id: 'maruf', labelBn: 'মারুফের পরিবার (নিজ)', labelEn: "Maruf's Family (Self)", iconEmoji: '🛡️' },
    { id: 'farjana', labelBn: 'ছোট বোন ফারজানা', labelEn: 'Farjana Hossain Branch', iconEmoji: '🌸' },
    { id: 'in_laws', labelBn: 'আত্মীয়স্বজন (মানিক ও রতন)', labelEn: 'In-Laws (Manik & Ratan)', iconEmoji: '🤝' },
  ];

  const roleBadgeStyles: Record<UserRole, { bg: string; text: string; border: string }> = {
    Admin: { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/40' },
    Editor: { bg: 'bg-blue-500/20', text: 'text-blue-300', border: 'border-blue-500/40' },
    Viewer: { bg: 'bg-slate-700/80', text: 'text-slate-300', border: 'border-slate-600' },
  };

  return (
    <div className="space-y-6">
      
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-900/90 via-slate-900 to-indigo-950 border border-emerald-500/20 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-72 h-72 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="max-w-2xl space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isBn ? 'মারুফের পারিবারিক ডিজিটাল পোর্টফোলিও' : "Maruf's Family Digital Vault & Directory"}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {isBn ? 'পারিবারিক সদস্য ডিরেক্টরি ও পোর্টফোলিও' : 'Family Member Directory & Profiles'}
            </h1>
            <p className="text-sm text-slate-300 leading-relaxed">
              {isBn 
                ? 'মরহুম মোঃ আব্দুল বারিক ভূঁইয়া ও নুর আক্তার পরিবারের সকল শাখা, সন্তান-সন্ততি, আত্মীয়স্বজন ও তাঁদের সংরক্ষিত আইনি দলিলের কেন্দ্রীয় ডিরেক্টরি।'
                : 'Centralized lineage and digital portfolio for the family of Late Md. Abdul Barek Bhuyan & Noor Akther with secure personal vault records.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            {canAdd ? (
              <button
                onClick={onOpenAddMemberModal}
                className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm shadow-lg shadow-emerald-900/40 transition"
              >
                <UserPlus className="w-4 h-4" />
                <span>{isBn ? 'নতুন সদস্য যোগ করুন' : 'Add Family Member'}</span>
              </button>
            ) : (
              <button
                onClick={onOpenVisitorRequestModal}
                className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 font-semibold text-sm shadow transition"
              >
                <Edit3 className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'তথ্য সংশোধনের অনুরোধ' : 'Request Info Update'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="space-y-4">
        {/* Branch Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
          {branches.map((b) => (
            <button
              key={b.id}
              onClick={() => setSelectedBranch(b.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedBranch === b.id
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/40'
                  : 'bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700/60'
              }`}
            >
              <span>{b.iconEmoji}</span>
              <span>{isBn ? b.labelBn : b.labelEn}</span>
              {b.id === 'maruf' && (
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-400 text-slate-950 text-[10px] font-black">
                  {isBn ? 'অ্যাডমিন' : 'Self'}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-4 top-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isBn 
                ? 'নাম, রক্তের গ্রুপ, পদবি বা সম্পর্ক দিয়ে সদস্য খুঁজুন...' 
                : 'Search family members by name, blood group, role...'
            }
            className="w-full pl-11 pr-4 py-3 rounded-2xl bg-slate-800/90 border border-slate-700/70 text-slate-100 placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-inner"
          />
        </div>
      </div>

      {/* Members Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredMembers.map((member) => {
          const isMaruf = member.id === 'maruf';
          const isPlaceholder = member.isPlaceholder;
          const isEditingThis = editingPlaceholderId === member.id;

          return (
            <div
              key={member.id}
              onClick={() => onSelectMember(member)}
              className={`group relative rounded-3xl p-5 border transition-all duration-300 cursor-pointer flex flex-col justify-between ${
                isMaruf
                  ? 'bg-gradient-to-b from-slate-800 via-slate-850 to-slate-900 border-emerald-500/50 shadow-xl shadow-emerald-950/20 ring-1 ring-emerald-500/30 hover:border-emerald-400'
                  : isPlaceholder
                  ? 'bg-amber-950/20 border-amber-600/40 hover:border-amber-400 hover:bg-amber-950/30'
                  : 'bg-slate-850/80 hover:bg-slate-800 border-slate-700/60 hover:border-slate-600 shadow-lg'
              }`}
            >
              {/* Top Row: Avatar & Badges */}
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-base shadow-md ${member.avatarColor}`}>
                      {member.nameBn.slice(0, 2)}
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                          isMaruf 
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                            : member.isDeceased
                            ? 'bg-slate-700 text-slate-300'
                            : isPlaceholder
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-slate-700/70 text-slate-300'
                        }`}>
                          {isBn ? member.roleBn : member.roleEn}
                        </span>

                        {/* RBAC System Role Tag */}
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${roleBadgeStyles[member.systemRole].bg} ${roleBadgeStyles[member.systemRole].text} ${roleBadgeStyles[member.systemRole].border}`}>
                          {member.systemRole}
                        </span>

                        {member.bloodGroup && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-rose-950/80 text-rose-300 border border-rose-800/50">
                            {member.bloodGroup}
                          </span>
                        )}
                      </div>
                      
                      {/* Name display or Inline edit */}
                      {isEditingThis ? (
                        <div className="mt-2 space-y-1.5" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="text"
                            value={placeholderInputBn}
                            onChange={(e) => setPlaceholderInputBn(e.target.value)}
                            placeholder="বাংলায় নাম লিখুন..."
                            className="w-full px-2.5 py-1 text-xs rounded-lg bg-slate-900 border border-amber-500 text-white focus:outline-none"
                            autoFocus
                          />
                          <input
                            type="text"
                            value={placeholderInputEn}
                            onChange={(e) => setPlaceholderInputEn(e.target.value)}
                            placeholder="English Name (Optional)..."
                            className="w-full px-2.5 py-1 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none"
                          />
                          <div className="flex items-center gap-2 pt-1">
                            <button
                              onClick={(e) => handleSavePlaceholder(member.id, e)}
                              className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs flex items-center gap-1"
                            >
                              <CheckCircle2 className="w-3 h-3" />
                              <span>{isBn ? 'সংরক্ষণ' : 'Save'}</span>
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingPlaceholderId(null);
                              }}
                              className="px-2 py-1 text-slate-400 hover:text-white text-xs"
                            >
                              {isBn ? 'বাতিল' : 'Cancel'}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <h3 className={`font-bold text-base mt-1 tracking-tight leading-snug ${
                          isPlaceholder ? 'text-amber-300 italic' : 'text-white'
                        }`}>
                          {isBn ? member.nameBn : member.nameEn}
                        </h3>
                      )}
                      
                      {!isEditingThis && (
                        <p className="text-xs text-slate-400">
                          {isBn ? member.nameEn : member.nameBn}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Placeholder edit button or Status icon */}
                  {isPlaceholder && !isEditingThis && canEdit && (
                    <button
                      onClick={(e) => handleStartEditPlaceholder(member, e)}
                      title={isBn ? 'নাম ইনপুট দিন' : 'Input Name'}
                      className="p-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 transition border border-amber-500/40 flex items-center gap-1 text-xs font-semibold"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span className="text-[10px]">{isBn ? 'নাম লিখুন' : 'Input'}</span>
                    </button>
                  )}
                </div>

                {/* Additional Info / Occupation / Location */}
                <div className="space-y-1.5 text-xs text-slate-300 mt-2">
                  {member.occupationBn && (
                    <div className="flex items-center gap-2 text-slate-300">
                      <span className="text-slate-500">💼</span>
                      <span>{isBn ? member.occupationBn : member.occupationEn}</span>
                    </div>
                  )}

                  {member.phone && !settings.hideSensitiveDataForGuests && (
                    <div className="flex items-center gap-2 text-slate-300">
                      <Phone className="w-3.5 h-3.5 text-slate-500" />
                      <span>{member.phone}</span>
                    </div>
                  )}

                  {member.notesBn && (
                    <p className="text-[11px] text-slate-400 line-clamp-2 mt-1 italic">
                      {isBn ? member.notesBn : member.notesEn}
                    </p>
                  )}
                </div>
              </div>

              {/* Bottom Row: Vault Docs Link & View Details */}
              <div className="mt-4 pt-3 border-t border-slate-700/50 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-slate-400">
                  <FileCheck2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>
                    {isBn 
                      ? `${member.documentCount || 0}টি নথি সংরক্ষিত` 
                      : `${member.documentCount || 0} Docs in Vault`}
                  </span>
                </div>

                <div className="flex items-center gap-1 text-emerald-400 group-hover:text-emerald-300 font-semibold">
                  <span>{isBn ? 'প্রোফাইল দেখুন' : 'View Profile'}</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
