import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Unlock, 
  KeyRound, 
  Users, 
  Sparkles, 
  ShieldAlert, 
  Eye, 
  EyeOff, 
  Languages, 
  Volume2, 
  VolumeX, 
  Music, 
  Radio, 
  CheckCircle2, 
  UserCheck, 
  ArrowRight,
  Shield,
  FileLock2
} from 'lucide-react';
import { FamilyMember, Language, UserRole } from '../types/family';
import { soundEffects } from '../utils/soundEffects';

interface LoginPageProps {
  members: FamilyMember[];
  language: Language;
  onToggleLanguage: () => void;
  onLoginSuccess: (memberId: string, role: UserRole) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  members,
  language,
  onToggleLanguage,
  onLoginSuccess,
  soundEnabled,
  onToggleSound,
}) => {
  const isBn = language === 'bn';
  const [activeTab, setActiveTab] = useState<'maruf' | 'family' | 'visitor'>('maruf');

  // Maruf Admin inputs
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Family Member inputs
  const [selectedMemberId, setSelectedMemberId] = useState<string>('omar_faruque');
  const [familyPin, setFamilyPin] = useState('1234');

  // Music state
  const [isMusicOn, setIsMusicOn] = useState(false);

  // Toggle ambient synthesizer
  const handleToggleMusic = () => {
    const isPlaying = soundEffects.toggleAmbientMusic();
    setIsMusicOn(isPlaying);
    soundEffects.playClick(soundEnabled);
  };

  // Submit Maruf Master Login
  const handleMarufLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg('');

    const cleanPass = password.trim().toLowerCase();
    if (cleanPass === 'maruf123' || cleanPass === '1985' || cleanPass === 'admin' || cleanPass === 'maruf') {
      soundEffects.playUnlock(soundEnabled);
      soundEffects.playSuccess(soundEnabled);
      onLoginSuccess('maruf', 'Admin');
    } else {
      soundEffects.playAlert(soundEnabled);
      setErrorMsg(isBn ? 'ভুল পাসওয়ার্ড বা পিন! সঠিক মাস্টার পিন প্রদান করুন।' : 'Invalid Master Passphrase or PIN!');
    }
  };

  // Quick 1-click Demo Bypass for Maruf
  const handleQuickMarufLogin = () => {
    soundEffects.playUnlock(soundEnabled);
    soundEffects.playSuccess(soundEnabled);
    onLoginSuccess('maruf', 'Admin');
  };

  // Submit Family Member Login
  const handleFamilyLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const targetMember = members.find((m) => m.id === selectedMemberId);
    if (!targetMember) return;

    soundEffects.playUnlock(soundEnabled);
    onLoginSuccess(targetMember.id, targetMember.systemRole);
  };

  // Submit Restricted Visitor Entry
  const handleVisitorLogin = () => {
    soundEffects.playClick(soundEnabled);
    // Find or fallback to viewer role
    onLoginSuccess('visitor_guest', 'Viewer');
  };

  const selectableMembers = members.filter((m) => !m.isPlaceholder && !m.isDeceased);

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4 bg-slate-950 text-slate-100 overflow-hidden font-sans">
      
      {/* Background Animated Cyber Mesh & Glowing Orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-emerald-600/20 rounded-full blur-[128px] animate-pulse" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-[128px] animate-pulse" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-teal-500/10 rounded-full blur-[160px]" />
        
        {/* Subtle grid pattern */}
        <div 
          className="absolute inset-0 opacity-[0.03]" 
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #fff 1px, transparent 0)`,
            backgroundSize: '32px 32px'
          }}
        />
      </div>

      {/* Top Floating Controls (Language, Sound, Ambient Music) */}
      <div className="absolute top-4 sm:top-6 right-4 sm:right-6 z-30 flex items-center gap-2">
        {/* Music Synth Toggle */}
        <button
          onClick={handleToggleMusic}
          title={isBn ? 'আবহ সঙ্গীত অন/অফ' : 'Toggle Ambient Family Music'}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold backdrop-blur-md transition-all shadow-lg ${
            isMusicOn 
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-emerald-950/40' 
              : 'bg-slate-900/80 text-slate-400 border-slate-700/80 hover:text-slate-200'
          }`}
        >
          <Music className={`w-3.5 h-3.5 ${isMusicOn ? 'animate-bounce text-emerald-400' : ''}`} />
          <span className="hidden sm:inline">
            {isBn ? (isMusicOn ? 'সঙ্গীত চলছে' : 'আবহ সঙ্গীত') : (isMusicOn ? 'Music ON' : 'Ambient Music')}
          </span>
          {isMusicOn && (
            <span className="flex gap-0.5 items-end h-3">
              <span className="w-0.5 h-2 bg-emerald-400 animate-pulse" />
              <span className="w-0.5 h-3 bg-emerald-400 animate-pulse delay-75" />
              <span className="w-0.5 h-1.5 bg-emerald-400 animate-pulse delay-150" />
            </span>
          )}
        </button>

        {/* Sound FX Toggle */}
        <button
          onClick={() => {
            onToggleSound();
            soundEffects.playClick(!soundEnabled);
          }}
          title={isBn ? 'সাউন্ড ইফেক্টস' : 'Sound Effects'}
          className={`p-2 rounded-xl border backdrop-blur-md text-xs font-semibold transition shadow-lg ${
            soundEnabled 
              ? 'bg-slate-800/80 text-teal-300 border-teal-500/40' 
              : 'bg-slate-900/80 text-slate-500 border-slate-800'
          }`}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Language Switcher */}
        <button
          onClick={() => {
            soundEffects.playClick(soundEnabled);
            onToggleLanguage();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700/80 text-xs font-semibold transition backdrop-blur-md shadow-lg"
        >
          <Languages className="w-3.5 h-3.5 text-emerald-400" />
          <span>{isBn ? 'English' : 'বাংলা'}</span>
        </button>
      </div>

      {/* Main Login Card Container */}
      <div className="relative z-10 w-full max-w-lg mx-auto">
        
        {/* Glow Header Frame */}
        <div className="relative rounded-3xl bg-slate-900/80 backdrop-blur-xl border border-slate-700/70 shadow-2xl p-6 sm:p-8 overflow-hidden">
          
          {/* Subtle top rainbow accent */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-400 to-indigo-600" />

          {/* Logo & Vault Branding */}
          <div className="text-center space-y-3 pb-6 border-b border-slate-800/80">
            <div className="relative inline-flex items-center justify-center">
              <div className="absolute inset-0 bg-emerald-500/30 rounded-3xl blur-xl animate-pulse" />
              <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-indigo-600 flex items-center justify-center text-white shadow-xl shadow-emerald-950/60 border border-emerald-400/30">
                <ShieldCheck className="w-9 h-9" />
              </div>
            </div>

            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[11px] font-bold tracking-wide uppercase mb-1.5">
                <Shield className="w-3 h-3" />
                <span>{isBn ? 'সুরক্ষিত পারিবারিক গেটওয়ে' : 'Encrypted Family Gateway'}</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {isBn ? 'মারুফের পরিবার ডিজিটাল ভল্ট' : "Maruf's Family Digital Vault"}
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 max-w-sm mx-auto mt-1">
                {isBn 
                  ? 'উত্তরাধিকার ফারায়েয, আইনি এআই ও ভূমির দলিল সংরক্ষণাগার' 
                  : 'Inheritance Succession, Legal AI & Family Document Repository'}
              </p>
            </div>
          </div>

          {/* Gate Selection Tabs */}
          <div className="mt-6 grid grid-cols-3 gap-1.5 p-1 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs">
            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setActiveTab('maruf');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 text-center ${
                activeTab === 'maruf'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-950/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{isBn ? 'মারুফ (Admin)' : 'Maruf (Admin)'}</span>
            </button>

            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setActiveTab('family');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 text-center ${
                activeTab === 'family'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-indigo-950/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>{isBn ? 'সদস্য লগইন' : 'Family Member'}</span>
            </button>

            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setActiveTab('visitor');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 text-center ${
                activeTab === 'visitor'
                  ? 'bg-slate-800 text-amber-300 shadow-md border border-amber-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>{isBn ? 'ভিজিটর গেট' : 'Visitor Gate'}</span>
            </button>
          </div>

          {/* TAB 1: MARUF MASTER ADMIN */}
          {activeTab === 'maruf' && (
            <div className="mt-6 space-y-4">
              <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-200 flex items-start gap-3">
                <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
                  <UserCheck className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-white mb-0.5">
                    {isBn ? 'ভল্ট প্রধান: হাবিবুর রহমান (মারুফ)' : 'Vault Master: Habibur Rahman (Maruf)'}
                  </p>
                  <p className="text-[11px] text-emerald-300/80 leading-relaxed">
                    {isBn 
                      ? 'সম্পূর্ণ প্রশাসনিক নিয়ন্ত্রণ, সদস্য ভূমিকা (Admin, Editor, Viewer) নির্ধারণ, অডিট ট্রেইল ও ভল্ট এনক্রিপশন কী পরিচালনা।'
                      : 'Full administrative authority, role management, audit security trails & encryption keys control.'}
                  </p>
                </div>
              </div>

              <form onSubmit={handleMarufLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    {isBn ? 'মাস্টার পাসওয়ার্ড / পিন' : 'Master Password / PIN'}
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={isBn ? 'পাসওয়ার্ড দিন (যেমন: maruf123 বা 1985)' : 'Enter password (e.g. maruf123 or 1985)'}
                      className="w-full pl-4 pr-11 py-3 rounded-xl bg-slate-950/80 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {errorMsg && (
                    <p className="text-xs text-rose-400 mt-1.5 flex items-center gap-1 font-medium">
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>{errorMsg}</span>
                    </p>
                  )}
                </div>

                <div className="pt-1 flex flex-col gap-2.5">
                  <button
                    type="submit"
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 hover:from-emerald-500 to-teal-600 hover:to-teal-500 text-white font-bold text-sm transition-all shadow-lg shadow-emerald-950/60 flex items-center justify-center gap-2"
                  >
                    <Unlock className="w-4 h-4" />
                    <span>{isBn ? 'মারুফ হিসেবে আনলক করুন' : 'Unlock as Maruf (Admin)'}</span>
                  </button>

                  {/* 1-Click Fast Demo Login */}
                  <button
                    type="button"
                    onClick={handleQuickMarufLogin}
                    className="w-full py-2.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-emerald-400 hover:text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>{isBn ? '১-ক্লিকে টেস্ট লগইন (ডেমো এক্সেস)' : '1-Click Quick Demo Login (Maruf)'}</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 2: FAMILY MEMBER LOGIN */}
          {activeTab === 'family' && (
            <div className="mt-6 space-y-4">
              <div className="p-3.5 rounded-2xl bg-blue-950/40 border border-blue-500/30 text-xs text-blue-200">
                <p className="font-bold text-white mb-0.5">
                  {isBn ? 'পারিবারিক সদস্য এক্সেস পোর্টাল' : 'Family Member Portal'}
                </p>
                <p className="text-[11px] text-blue-300/80 leading-relaxed">
                  {isBn 
                    ? 'আপনার প্রোফাইল নির্বাচন করে নির্ধারিত ভূমিকা (Editor বা Viewer) হিসেবে প্রবেশ করুন।'
                    : 'Select your family member profile and enter with your designated RBAC role.'}
                </p>
              </div>

              <form onSubmit={handleFamilyLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    {isBn ? 'পারিবারিক সদস্য নির্বাচন করুন' : 'Select Family Member'}
                  </label>
                  <select
                    value={selectedMemberId}
                    onChange={(e) => setSelectedMemberId(e.target.value)}
                    className="w-full p-3 rounded-xl bg-slate-950/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500 text-sm"
                  >
                    {selectableMembers.map((m) => (
                      <option key={m.id} value={m.id}>
                        {isBn ? m.nameBn : m.nameEn} ({m.systemRole} - {isBn ? m.roleBn : m.roleEn})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    {isBn ? 'পারিবারিক পিন (ডিফল্ট: 1234)' : 'Family PIN (Default: 1234)'}
                  </label>
                  <input
                    type="password"
                    value={familyPin}
                    onChange={(e) => setFamilyPin(e.target.value)}
                    className="w-full p-3 rounded-xl bg-slate-950/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"
                  />
                </div>

                {/* Selected Role Preview */}
                {(() => {
                  const m = members.find((x) => x.id === selectedMemberId);
                  if (!m) return null;
                  return (
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">{isBn ? 'নির্ধারিত ভূমিকা:' : 'Assigned Role:'}</span>
                        <span className={`px-2 py-0.5 rounded-full font-bold ${
                          m.systemRole === 'Editor' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40' : 'bg-slate-800 text-slate-300 border border-slate-700'
                        }`}>
                          {m.systemRole}
                        </span>
                      </div>
                      <p className="text-slate-400">
                        {m.systemRole === 'Editor'
                          ? (isBn ? '✓ আপনি পরিবারের তথ্য ও নতুন দলিল আপলোড ও সম্পাদনা করতে পারবেন।' : '✓ You can add & edit family profiles and documents.')
                          : (isBn ? '✓ আপনি শুধুমাত্র পারিবারিক তথ্য ও দলিলসমূহ দেখতে পারবেন।' : '✓ You can view family information and documents in read-only mode.')}
                      </p>
                    </div>
                  );
                })()}

                <button
                  type="submit"
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-blue-600 hover:from-blue-500 to-indigo-600 hover:to-indigo-500 text-white font-bold text-sm transition-all shadow-lg flex items-center justify-center gap-2"
                >
                  <Unlock className="w-4 h-4" />
                  <span>{isBn ? 'সদস্য হিসেবে প্রবেশ করুন' : 'Login as Family Member'}</span>
                </button>
              </form>
            </div>
          )}

          {/* TAB 3: RESTRICTED VISITOR GATE */}
          {activeTab === 'visitor' && (
            <div className="mt-6 space-y-4">
              <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 text-xs text-amber-200 space-y-2">
                <div className="flex items-center gap-2 font-bold text-amber-300">
                  <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{isBn ? 'কঠোর নিরাপত্তা নীতি ও ভিজিটর কোয়ারেন্টাইন' : 'Visitor Policy & Strict Quarantine'}</span>
                </div>
                <p className="text-[11px] text-amber-200/90 leading-relaxed">
                  {isBn 
                    ? '⚠️ যে কোনো বহিরাগত বা অননুমোদিত ভিজিটর সরাসরি ভল্টে কোনো দলিল বা তথ্য প্রকাশ করতে পারবে না। আপনার কোনো অনুরোধ বা আপলোড থাকলে তা মারুফের রিভিউ কিউ-তে জমা হবে।'
                    : '⚠️ Visitors are strictly restricted from publishing any data directly. Any query or upload is quarantined for Maruf\'s cryptographic review.'}
                </p>
              </div>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{isBn ? 'পারিবারিক রক্ত সম্পর্কের পরিচিতি দেখা যাবে' : 'Browse verified family pedigree & contacts'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{isBn ? 'উত্তরাধিকার আইন ও ফারায়েয ক্যালকুলেটর ব্যবহারযোগ্য' : 'Calculate Islamic inheritance distribution'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{isBn ? 'ই-নামজারি সহায়িকা ও এআই পরামর্শ নেওয়া যাবে' : 'Access legal AI & e-Namjari guides'}</span>
                </div>
                <div className="flex items-center gap-2 text-rose-400">
                  <Lock className="w-4 h-4" />
                  <span>{isBn ? 'গোপন দলিল ডাউনলোড ও প্রকাশ সম্পূর্ণ নিষিদ্ধ' : 'Confidential deed publishing is strictly blocked'}</span>
                </div>
              </div>

              <button
                onClick={handleVisitorLogin}
                className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white border border-amber-500/30 font-bold text-sm transition-all shadow-md flex items-center justify-center gap-2"
              >
                <ArrowRight className="w-4 h-4" />
                <span>{isBn ? 'সীমাবদ্ধ দর্শক হিসেবে ব্রাউজ করুন (Guest Mode)' : 'Browse as Restricted Viewer (Guest)'}</span>
              </button>
            </div>
          )}

          {/* Bottom Security Assurance */}
          <div className="mt-8 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
            <span className="flex items-center gap-1.5">
              <FileLock2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>AES-256 Client Vault</span>
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
              <span>Role-Based Isolation (RBAC)</span>
            </span>
          </div>

        </div>

      </div>

    </div>
  );
};
