export type Language = 'bn' | 'en';

export type UserRole = 'Admin' | 'Editor' | 'Viewer';

export type BranchCategory = 
  | 'all'
  | 'parents'
  | 'omar_faruque'
  | 'abdul_kader'
  | 'maruf'
  | 'farjana'
  | 'in_laws';

export interface FamilyMember {
  id: string;
  nameBn: string;
  nameEn: string;
  roleBn: string; // Kinship role (e.g. পিতা, বড় ভাই, বোন)
  roleEn: string;
  systemRole: UserRole; // RBAC System Role: Admin | Editor | Viewer
  branch: BranchCategory;
  generation: number; // 1 = Parents, 2 = Siblings & In-laws, 3 = Children
  isDeceased?: boolean;
  photoUrl?: string;
  avatarColor: string;
  gender: 'male' | 'female';
  phone?: string;
  email?: string;
  bloodGroup?: string;
  occupationBn?: string;
  occupationEn?: string;
  addressBn?: string;
  addressEn?: string;
  nidOrBirthCert?: string;
  notesBn?: string;
  notesEn?: string;
  isPlaceholder?: boolean;
  placeholderHintBn?: string;
  placeholderHintEn?: string;
  relationships: {
    father?: string;
    mother?: string;
    spouse?: string;
    exSpouse?: string;
    children?: string[];
    siblings?: string[];
  };
  documentCount?: number;
}

export interface RolePermissions {
  canAddDocument: boolean;
  canEditDocument: boolean;
  canDeleteDocument: boolean;
  canEditMemberProfile: boolean;
  canAddMember: boolean;
  canDeleteMember: boolean;
  canAssignRoles: boolean;
  canApproveVisitorRequests: boolean;
  canAccessAdminPanel: boolean;
  canModifySystemSettings: boolean;
}

export const ROLE_PERMISSIONS: Record<UserRole, RolePermissions> = {
  Admin: {
    canAddDocument: true,
    canEditDocument: true,
    canDeleteDocument: true,
    canEditMemberProfile: true,
    canAddMember: true,
    canDeleteMember: true,
    canAssignRoles: true,
    canApproveVisitorRequests: true,
    canAccessAdminPanel: true,
    canModifySystemSettings: true,
  },
  Editor: {
    canAddDocument: true,
    canEditDocument: true,
    canDeleteDocument: false,
    canEditMemberProfile: true,
    canAddMember: false,
    canDeleteMember: false,
    canAssignRoles: false,
    canApproveVisitorRequests: false,
    canAccessAdminPanel: false,
    canModifySystemSettings: false,
  },
  Viewer: {
    canAddDocument: false,
    canEditDocument: false,
    canDeleteDocument: false,
    canEditMemberProfile: false,
    canAddMember: false,
    canDeleteMember: false,
    canAssignRoles: false,
    canApproveVisitorRequests: false,
    canAccessAdminPanel: false,
    canModifySystemSettings: false,
  },
};

export interface VaultDocument {
  id: string;
  titleBn: string;
  titleEn: string;
  category: 'land' | 'identity' | 'inheritance' | 'academic' | 'other';
  memberId?: string;
  memberNameBn?: string;
  memberNameEn?: string;
  issueDate?: string;
  expiryDate?: string;
  documentNumber?: string;
  fileType: 'pdf' | 'image' | 'deed';
  fileSize: string;
  isEncrypted: boolean;
  encryptionHash: string;
  notesBn?: string;
  notesEn?: string;
  verified: boolean;
}

export interface VisitorRequest {
  id: string;
  submitterName: string;
  submitterPhone: string;
  submitterEmail?: string;
  relationClaimBn: string;
  relationClaimEn: string;
  requestType: 'document_upload' | 'info_update' | 'contact_query';
  title: string;
  description: string;
  targetMemberId?: string;
  submittedAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface AdminSettings {
  accentColor: 'emerald' | 'sapphire' | 'slate' | 'amber';
  layoutDensity: 'compact' | 'comfortable' | 'spacious';
  hideSensitiveDataForGuests: boolean;
  autoSpeakAiVoice: boolean;
  voiceLanguage: 'bn-BD' | 'en-US';
  cronSecret: string;
  soundEffectsEnabled?: boolean;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actionType: 'role_change' | 'file_upload' | 'member_edit' | 'security_login' | 'visitor_approval' | 'system_alert' | 'visitor_blocked';
  severity: 'info' | 'warning' | 'critical' | 'success';
  performedBy: string; // e.g. "হাবিবুর রহমান (মারুফ) [Admin]"
  targetSubject: string; // e.g. "ওমর ফারুক", "Dhanmondi Plot Deed"
  detailsBn: string;
  detailsEn: string;
  ipAddress?: string;
  deviceInfo?: string;
}

export interface TipPost {
  id: string;
  titleBn: string;
  titleEn: string;
  category: 'legal_tips' | 'land_sale' | 'vault_security' | 'inheritance';
  summaryBn: string;
  summaryEn: string;
  contentBn: string;
  contentEn: string;
  readTime: string;
  publishedDate: string;
  likes: number;
  tags: string[];
}
