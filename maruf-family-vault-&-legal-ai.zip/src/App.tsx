import React, { useState } from 'react';
import { Header } from './components/Header';
import { LoginPage } from './components/LoginPage';
import { FamilyDirectory } from './components/FamilyDirectory';
import { MemberDetailModal } from './components/MemberDetailModal';
import { DocumentVault } from './components/DocumentVault';
import { InheritanceCalculator } from './components/InheritanceCalculator';
import { LandSaleTracker } from './components/LandSaleTracker';
import { AILegalAssistant } from './components/AILegalAssistant';
import { FamilyBlogTips } from './components/FamilyBlogTips';
import { AdminPanel } from './components/AdminPanel';
import { AdminLoginModal } from './components/AdminLoginModal';
import { VisitorRequestModal } from './components/VisitorRequestModal';
import { AddMemberModal } from './components/AddMemberModal';
import { ExpiryAlertBanner } from './components/ExpiryAlertBanner';
import { 
  initialFamilyMembers, 
  initialDocuments, 
  initialVisitorRequests, 
  initialAdminSettings,
  initialAuditLogs,
  initialTipPosts
} from './data/initialData';
import { 
  FamilyMember, 
  VaultDocument, 
  VisitorRequest, 
  AdminSettings, 
  Language, 
  UserRole,
  AuditLogEntry,
  TipPost
} from './types/family';
import { soundEffects } from './utils/soundEffects';
import { 
  Lock, 
  ShieldAlert, 
  UserCheck, 
  Sparkles, 
  ShieldCheck, 
  Bell, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowRight,
  Shield,
  FileCheck2,
  Clock
} from 'lucide-react';

export default function App() {
  // Primary State
  const [language, setLanguage] = useState<Language>('bn'); // Bangla is primary default
  const [currentTab, setCurrentTab] = useState<string>('directory');
  const [members, setMembers] = useState<FamilyMember[]>(initialFamilyMembers);
  const [documents, setDocuments] = useState<VaultDocument[]>(initialDocuments);
  const [requests, setRequests] = useState<VisitorRequest[]>(initialVisitorRequests);
  const [settings, setSettings] = useState<AdminSettings>(initialAdminSettings);
  const [logs, setLogs] = useState<AuditLogEntry[]>(initialAuditLogs);
  const [posts, setPosts] = useState<TipPost[]>(initialTipPosts);

  // Authentication & Gatekeeper State
  // User explicitly asked: "MUST BE LOGIN PAGE NOT ANYONE PUBLISH ANY VISITORS"
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true); // Starts logged in as Maruf by default for instant evaluation, or toggleable to login page
  const [currentUserId, setCurrentUserId] = useState<string>('maruf');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(true);

  // Sound & Ambient Music State
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isMusicOn, setIsMusicOn] = useState<boolean>(false);

  // Modals & UI View State
  const [selectedMember, setSelectedMember] = useState<FamilyMember | null>(null);
  const [isAdminLoginModalOpen, setIsAdminLoginModalOpen] = useState<boolean>(false);
  const [isVisitorRequestModalOpen, setIsVisitorRequestModalOpen] = useState<boolean>(false);
  const [isAddMemberModalOpen, setIsAddMemberModalOpen] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [activeAiTopic, setActiveAiTopic] = useState<string | null>(null);
  const [globalToast, setGlobalToast] = useState<{ message: string; type: 'success' | 'info' | 'warning' } | null>(null);

  const isBn = language === 'bn';

  // Current active user object & computed RBAC system role
  const currentUser: FamilyMember = members.find((m) => m.id === currentUserId) || {
    id: 'visitor_guest',
    nameBn: 'সম্মানিত অতিথি (Visitor)',
    nameEn: 'Guest Visitor',
    roleBn: 'বহিরাগত দর্শক',
    roleEn: 'Guest Viewer',
    systemRole: 'Viewer',
    branch: 'in_laws',
    generation: 2,
    avatarColor: 'bg-slate-700 text-slate-300',
    gender: 'male',
    relationships: {},
  };

  const activeRole: UserRole = currentUser.systemRole;

  // Trigger temporary toast notification
  const showToast = (message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    setGlobalToast({ message, type });
    setTimeout(() => setGlobalToast(null), 4000);
  };

  // Append new event to the Audit Trail
  const addAuditLog = (
    actionType: AuditLogEntry['actionType'],
    severity: AuditLogEntry['severity'],
    targetSubject: string,
    detailsBn: string,
    detailsEn: string
  ) => {
    const newEntry: AuditLogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      actionType,
      severity,
      performedBy: `${isBn ? currentUser.nameBn : currentUser.nameEn} [${activeRole}]`,
      targetSubject,
      detailsBn,
      detailsEn,
      ipAddress: '103.114.98.24',
      deviceInfo: 'Family Secure Client',
    };
    setLogs((prev) => [newEntry, ...prev]);
  };

  // Expiry counts calculation
  const now = new Date().getTime();
  const expiringDocsCount = documents.filter((doc) => {
    if (!doc.expiryDate) return false;
    const exp = new Date(doc.expiryDate).getTime();
    const daysLeft = Math.ceil((exp - now) / (1000 * 60 * 60 * 24));
    return daysLeft <= 30 && daysLeft >= 0;
  }).length;

  const urgent7DaysCount = documents.filter((doc) => {
    if (!doc.expiryDate) return false;
    const exp = new Date(doc.expiryDate).getTime();
    const daysLeft = Math.ceil((exp - now) / (1000 * 60 * 60 * 24));
    return daysLeft <= 7 && daysLeft >= 0;
  }).length;

  const pendingRequestsCount = requests.filter((r) => r.status === 'pending').length;

  // Toggle Language
  const handleToggleLanguage = () => {
    setLanguage((prev) => (prev === 'bn' ? 'en' : 'bn'));
  };

  // Ambient Music Synthesizer
  const handleToggleMusic = () => {
    const isPlaying = soundEffects.toggleAmbientMusic();
    setIsMusicOn(isPlaying);
  };

  // Sound FX Toggle
  const handleToggleSound = () => {
    setSoundEnabled(!soundEnabled);
  };

  // User Login from Login Gate
  const handleLoginSuccess = (memberId: string, role: UserRole) => {
    setIsAuthenticated(true);
    setCurrentUserId(memberId);
    if (role === 'Admin') {
      setIsAdminLoggedIn(true);
    } else {
      setIsAdminLoggedIn(false);
    }
    const memberObj = members.find((m) => m.id === memberId);
    const memberName = memberObj ? (isBn ? memberObj.nameBn : memberObj.nameEn) : 'Guest';

    addAuditLog(
      'security_login',
      'success',
      'লগইন গেটওয়ে (Auth Gateway)',
      `${memberName} (${role}) সফলভাবে ভল্টে লগইন করেছেন।`,
      `${memberName} (${role}) successfully authenticated to the vault.`
    );

    showToast(
      isBn ? `${memberName} হিসেবে লগইন সফল!` : `Successfully logged in as ${memberName}!`,
      'success'
    );
  };

  // Vault Lock / Logout -> returns to LoginPage
  const handleLockVault = () => {
    soundEffects.playLock(soundEnabled);
    setIsAuthenticated(false);
    setIsAdminLoggedIn(false);
    addAuditLog(
      'security_login',
      'info',
      'ভল্ট সেশন',
      `${isBn ? currentUser.nameBn : currentUser.nameEn} ভল্ট সেশন সমাপ্ত করে লক করেছেন।`,
      `${currentUser.nameEn} locked the vault session.`
    );
  };

  // Switch Active User to simulate RBAC roles
  const handleSwitchUser = (memberId: string) => {
    setCurrentUserId(memberId);
    const target = members.find((m) => m.id === memberId);
    if (target && target.systemRole === 'Admin') {
      setIsAdminLoggedIn(true);
    } else {
      setIsAdminLoggedIn(false);
    }

    if (target) {
      showToast(
        isBn 
          ? `ভূমিকা পরিবর্তন: ${target.nameBn} (${target.systemRole}) সক্রিয়!` 
          : `Active user switched to: ${target.nameEn} (${target.systemRole})!`,
        'info'
      );
    }
  };

  // Mechanism for Maruf (Admin) to assign RBAC roles to family members
  const handleAssignRole = (memberId: string, newRole: UserRole) => {
    const target = members.find((m) => m.id === memberId);
    const targetName = target ? (isBn ? target.nameBn : target.nameEn) : 'Member';

    setMembers((prev) =>
      prev.map((m) => (m.id === memberId ? { ...m, systemRole: newRole } : m))
    );
    if (selectedMember && selectedMember.id === memberId) {
      setSelectedMember({ ...selectedMember, systemRole: newRole });
    }

    soundEffects.playRoleAssign(soundEnabled);

    // Record into Audit Trail
    addAuditLog(
      'role_change',
      'success',
      targetName,
      `মারুফ (Admin) কর্তৃক ${targetName}-এর সিস্টেম ভূমিকা "${newRole}" হিসেবে নির্ধারণ করা হয়েছে।`,
      `Maruf (Admin) updated ${targetName}'s system access role to "${newRole}".`
    );

    showToast(
      isBn 
        ? `সফলভাবে ${targetName}-এর ভূমিকা "${newRole}" নির্ধারণ করা হয়েছে!` 
        : `Successfully assigned role "${newRole}" to ${targetName}!`,
      'success'
    );
  };

  // Quick In-Card Placeholder Update
  const handleQuickUpdatePlaceholder = (id: string, newNameBn: string, newNameEn: string) => {
    setMembers((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          return {
            ...m,
            nameBn: newNameBn,
            nameEn: newNameEn,
            isPlaceholder: false,
          };
        }
        return m;
      })
    );

    soundEffects.playSuccess(soundEnabled);
    addAuditLog(
      'member_edit',
      'info',
      newNameBn,
      `পরিবারের সদস্যের কার্ডে নাম হালনাগাদ করা হয়েছে: ${newNameBn}`,
      `Updated member placeholder name to: ${newNameEn}`
    );

    showToast(isBn ? 'সদস্যের নাম হালনাগাদ হয়েছে!' : 'Member name updated!', 'success');
  };

  // Add Member
  const handleAddMember = (newMember: FamilyMember) => {
    setMembers((prev) => [...prev, newMember]);
    soundEffects.playSuccess(soundEnabled);
    addAuditLog(
      'member_edit',
      'success',
      newMember.nameBn,
      `নতুন সদস্য যুক্ত করা হয়েছে: ${newMember.nameBn} (${newMember.roleBn})`,
      `New family member added: ${newMember.nameEn}`
    );
    showToast(isBn ? 'নতুন সদস্য সফলভাবে যোগ করা হয়েছে!' : 'New member added!', 'success');
  };

  // Update Member
  const handleUpdateMember = (updated: FamilyMember) => {
    setMembers((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
    if (selectedMember && selectedMember.id === updated.id) {
      setSelectedMember(updated);
    }
    soundEffects.playSuccess(soundEnabled);
    addAuditLog(
      'member_edit',
      'info',
      updated.nameBn,
      `সদস্যের প্রোফাইল তথ্য হালনাগাদ করা হয়েছে: ${updated.nameBn}`,
      `Member profile updated: ${updated.nameEn}`
    );
    showToast(isBn ? 'প্রোফাইল তথ্য সংরক্ষিত হয়েছে!' : 'Profile updated!', 'success');
  };

  // Delete Member
  const handleDeleteMember = (id: string) => {
    const target = members.find((m) => m.id === id);
    const targetName = target ? (isBn ? target.nameBn : target.nameEn) : 'Member';
    setMembers((prev) => prev.filter((m) => m.id !== id));
    if (selectedMember && selectedMember.id === id) {
      setSelectedMember(null);
    }
    soundEffects.playAlert(soundEnabled);
    addAuditLog(
      'member_edit',
      'warning',
      targetName,
      `সদস্য ডিরেক্টরি থেকে সরানো হয়েছে: ${targetName}`,
      `Member removed from directory: ${targetName}`
    );
    showToast(isBn ? `${targetName} তালিকা থেকে সরানো হয়েছে` : 'Member removed', 'info');
  };

  // Add Document
  const handleAddDocument = (newDoc: VaultDocument) => {
    setDocuments((prev) => [newDoc, ...prev]);
    if (newDoc.memberId) {
      setMembers((prev) =>
        prev.map((m) =>
          m.id === newDoc.memberId
            ? { ...m, documentCount: (m.documentCount || 0) + 1 }
            : m
        )
      );
    }
    soundEffects.playSuccess(soundEnabled);
    addAuditLog(
      'file_upload',
      'success',
      newDoc.titleBn,
      `নতুন দলিল AES-256 এনক্রিপ্ট করে ভল্টে আপলোড করা হয়েছে: ${newDoc.titleBn}`,
      `New encrypted document uploaded: ${newDoc.titleEn}`
    );
    showToast(isBn ? 'দলিল ভল্টে নিরাপদে সংরক্ষিত হয়েছে!' : 'Document uploaded safely!', 'success');
  };

  // Approve Visitor Request
  const handleApproveRequest = (id: string) => {
    const req = requests.find((r) => r.id === id);
    if (!req) return;

    setRequests((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: 'approved' } : r))
    );

    // If target member placeholder was requested to be updated
    if (req.targetMemberId) {
      setMembers((prev) =>
        prev.map((m) => {
          if (m.id === req.targetMemberId) {
            return {
              ...m,
              nameBn: req.title,
              nameEn: req.title,
              isPlaceholder: false,
            };
          }
          return m;
        })
      );
    }

    soundEffects.playSuccess(soundEnabled);
    addAuditLog(
      'visitor_approval',
      'success',
      req.submitterName,
      `মারুফ কর্তৃক আবেদনকারী ${req.submitterName}-এর দলিল/তথ্য অনুরোধ অনুমোদন করা হয়েছে।`,
      `Approved request from ${req.submitterName}.`
    );
    showToast(isBn ? 'অনুরোধ অনুমোদিত হয়েছে!' : 'Request approved!', 'success');
  };

  // Reject Visitor Request
  const handleRejectRequest = (id: string) => {
    const req = requests.find((r) => r.id === id);
    setRequests((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: 'rejected' } : r))
    );
    soundEffects.playAlert(soundEnabled);
    addAuditLog(
      'visitor_approval',
      'warning',
      req ? req.submitterName : 'Request',
      `আবেদনকারী ${req ? req.submitterName : ''}-এর তথ্য অনুরোধ বাতিল করা হয়েছে।`,
      `Rejected request from ${req ? req.submitterName : ''}.`
    );
    showToast(isBn ? 'অনুরোধ বাতিল করা হয়েছে' : 'Request rejected', 'info');
  };

  // Submit Visitor Request (Quarantined)
  const handleSubmitVisitorRequest = (newReq: VisitorRequest) => {
    setRequests((prev) => [newReq, ...prev]);
    soundEffects.playAlert(soundEnabled);
    addAuditLog(
      'visitor_blocked',
      'warning',
      newReq.submitterName,
      `ভিজিটর সিকিউরিটি গেট: ${newReq.submitterName} কর্তৃক নতুন ফাইল জমা দেওয়া হয়েছে। স্বয়ংক্রিয়ভাবে কোয়ারেন্টাইনে রাখা হয়েছে।`,
      `Visitor file safely quarantined waiting for Maruf approval: ${newReq.title}`
    );
    showToast(
      isBn 
        ? 'অনুরোধটি মারুফের রিভিউ কিউ-তে কোয়ারেন্টাইনে জমা হয়েছে!' 
        : 'Request safely quarantined for Maruf\'s review!',
      'info'
    );
  };

  // Add Blog / Tip Post
  const handleAddTipPost = (newPost: TipPost) => {
    setPosts((prev) => [newPost, ...prev]);
    addAuditLog(
      'member_edit',
      'success',
      newPost.titleBn,
      `নতুন আইনি জ্ঞানকোষ পোস্ট প্রকাশিত হয়েছে: ${newPost.titleBn}`,
      `Published new legal tip: ${newPost.titleEn}`
    );
    showToast(isBn ? 'নতুন টিপস সফলভাবে প্রকাশিত হয়েছে!' : 'New tip published!', 'success');
  };

  // Handle Ask AI from Blog
  const handleAskAiAboutTopic = (topic: string) => {
    setActiveAiTopic(topic);
    setCurrentTab('ai');
    showToast(isBn ? 'এআই সহায়ক খোলা হয়েছে...' : 'Opening AI Assistant...', 'info');
  };

  // --- RENDER: LOGIN GATE SCREEN IF NOT AUTHENTICATED ---
  if (!isAuthenticated) {
    return (
      <LoginPage
        members={members}
        language={language}
        onToggleLanguage={handleToggleLanguage}
        onLoginSuccess={handleLoginSuccess}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
      />
    );
  }

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      
      {/* Global Toast Alert */}
      {globalToast && (
        <div className="fixed bottom-6 right-6 z-50 animate-bounce">
          <div className={`flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-2xl backdrop-blur-md border text-xs font-bold ${
            globalToast.type === 'success' 
              ? 'bg-emerald-950/90 text-emerald-200 border-emerald-500/50 shadow-emerald-950/60' 
              : globalToast.type === 'warning'
                ? 'bg-amber-950/90 text-amber-200 border-amber-500/50 shadow-amber-950/60'
                : 'bg-indigo-950/90 text-indigo-200 border-indigo-500/50 shadow-indigo-950/60'
          }`}>
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{globalToast.message}</span>
          </div>
        </div>
      )}

      {/* Top Expiry Warning Banner */}
      <ExpiryAlertBanner
        documents={documents}
        language={language}
        onOpenVault={() => setCurrentTab('vault')}
      />

      {/* Primary Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        language={language}
        onToggleLanguage={handleToggleLanguage}
        isAdminLoggedIn={isAdminLoggedIn}
        currentUser={currentUser}
        activeRole={activeRole}
        allMembers={members}
        onSwitchUser={handleSwitchUser}
        onOpenLoginModal={() => setIsAdminLoginModalOpen(true)}
        onLogoutAdmin={() => {
          setIsAdminLoggedIn(false);
          handleSwitchUser('noor_akther');
        }}
        onLockVault={handleLockVault}
        pendingRequestsCount={pendingRequestsCount}
        expiringDocsCount={expiringDocsCount}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        settings={settings}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        isMusicOn={isMusicOn}
        onToggleMusic={handleToggleMusic}
      />

      {/* Real-Time Dashboard Security & Quick Status Alert Bar */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <div className="p-3 sm:p-4 rounded-2xl bg-slate-900/90 border border-slate-800 backdrop-blur-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs shadow-md">
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Active User Status */}
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800 text-slate-300 border border-slate-700/80">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{isBn ? 'সক্রিয় ব্যবহারকারী:' : 'Active User:'}</span>
              <strong className="text-white">{isBn ? currentUser.nameBn : currentUser.nameEn}</strong>
              <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-bold ${
                activeRole === 'Admin' 
                  ? 'bg-emerald-500/20 text-emerald-300' 
                  : activeRole === 'Editor' 
                    ? 'bg-blue-500/20 text-blue-300' 
                    : 'bg-slate-700 text-slate-300'
              }`}>
                {activeRole}
              </span>
            </div>

            {/* Quarantined Visitor Submissions Notice */}
            {pendingRequestsCount > 0 ? (
              <button
                onClick={() => {
                  soundEffects.playClick(soundEnabled);
                  setCurrentTab('admin');
                }}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/15 text-amber-300 border border-amber-500/40 hover:bg-amber-500/25 transition cursor-pointer"
              >
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                <span>
                  {isBn 
                    ? `${pendingRequestsCount}টি ভিজিটর ফাইল কোয়ারেন্টাইনে রিভিউ প্রতীক্ষায়!` 
                    : `${pendingRequestsCount} visitor file quarantined for review!`}
                </span>
                <ArrowRight className="w-3 h-3" />
              </button>
            ) : (
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800/60 text-slate-400 border border-slate-750">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isBn ? 'ভিজিটর কোয়ারেন্টাইন গেট সক্রিয়' : 'Visitor Quarantine Gate Active'}</span>
              </div>
            )}

            {/* Urgent 7-day Alert */}
            {urgent7DaysCount > 0 && (
              <button
                onClick={() => setCurrentTab('vault')}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-rose-500/15 text-rose-300 border border-rose-500/40 hover:bg-rose-500/25 transition"
              >
                <Clock className="w-3.5 h-3.5 text-rose-400 animate-ping" />
                <span className="font-bold">
                  {isBn ? `${urgent7DaysCount}টি নথির মেয়াদ ৭ দিনের নিচে!` : `${urgent7DaysCount} docs expire in <7 days!`}
                </span>
              </button>
            )}
          </div>

          {/* Quick Shortcuts */}
          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <span className="hidden lg:inline">{isBn ? 'অডিট ট্রেইল অ্যাক্টিভ' : 'Audit Trail Online'}</span>
            <span className="hidden lg:inline">•</span>
            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setCurrentTab('tips');
              }}
              className="text-emerald-400 hover:text-emerald-300 hover:underline flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>{isBn ? 'আইনি টিপস ও ট্রিকস' : 'Tips & Tricks'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Tab Content View */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'directory' && (
          <FamilyDirectory
            members={members}
            language={language}
            userRole={activeRole}
            onSelectMember={(m) => setSelectedMember(m)}
            onQuickUpdatePlaceholder={handleQuickUpdatePlaceholder}
            onOpenAddMemberModal={() => setIsAddMemberModalOpen(true)}
            onOpenVisitorRequestModal={() => setIsVisitorRequestModalOpen(true)}
            isAdminLoggedIn={isAdminLoggedIn}
            settings={settings}
          />
        )}

        {currentTab === 'vault' && (
          <DocumentVault
            documents={documents}
            members={members}
            language={language}
            userRole={activeRole}
            onAddDocument={handleAddDocument}
            isAdminLoggedIn={isAdminLoggedIn}
          />
        )}

        {currentTab === 'inheritance' && (
          <InheritanceCalculator language={language} />
        )}

        {currentTab === 'enamjari' && (
          <LandSaleTracker language={language} />
        )}

        {currentTab === 'ai' && (
          <AILegalAssistant 
            language={language} 
          />
        )}

        {currentTab === 'tips' && (
          <FamilyBlogTips
            posts={posts}
            language={language}
            userRole={activeRole}
            onAskAiTopic={handleAskAiAboutTopic}
            soundEnabled={soundEnabled}
            onAddPost={handleAddTipPost}
          />
        )}

        {currentTab === 'admin' && (
          activeRole === 'Admin' || isAdminLoggedIn ? (
            <AdminPanel
              members={members}
              documents={documents}
              requests={requests}
              logs={logs}
              settings={settings}
              language={language}
              soundEnabled={soundEnabled}
              onToggleSound={handleToggleSound}
              onUpdateMember={handleUpdateMember}
              onDeleteMember={handleDeleteMember}
              onOpenAddMemberModal={() => setIsAddMemberModalOpen(true)}
              onApproveRequest={handleApproveRequest}
              onRejectRequest={handleRejectRequest}
              onUpdateSettings={setSettings}
              onAssignRole={handleAssignRole}
            />
          ) : (
            <div className="max-w-xl mx-auto py-12 px-6 rounded-3xl bg-slate-850 border border-slate-700 text-center space-y-4 shadow-2xl">
              <div className="w-16 h-16 rounded-3xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center mx-auto shadow-lg">
                <Lock className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-white">
                {isBn ? 'অ্যাডমিন এক্সেস সংরক্ষিত (Admin Access Required)' : 'Admin Access Required'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {isBn 
                  ? `আপনার বর্তমান ভূমিকা "${activeRole}" (${isBn ? currentUser.nameBn : currentUser.nameEn})। অ্যাডমিন কন্ট্রোল প্যানেলে শুধুমাত্র মারুফ (Admin) প্রবেশ করতে পারেন।`
                  : `Your active role is "${activeRole}" (${currentUser.nameEn}). The Admin Control Panel is strictly reserved for Maruf (Admin).`}
              </p>
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => handleSwitchUser('maruf')}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition shadow flex items-center justify-center gap-2"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>{isBn ? 'মারুফ (Admin)-এ স্যুইচ করুন' : 'Switch to Maruf (Admin)'}</span>
                </button>
                <button
                  onClick={() => setIsAdminLoginModalOpen(true)}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold border border-slate-700 transition"
                >
                  <span>{isBn ? 'পাসওয়ার্ড দিয়ে লগইন করুন' : 'Login with Passphrase'}</span>
                </button>
              </div>
            </div>
          )
        )}
      </main>

      {/* Dedicated Member Detail Drawer / Modal */}
      {selectedMember && (
        <MemberDetailModal
          member={selectedMember}
          allMembers={members}
          documents={documents}
          language={language}
          userRole={activeRole}
          onClose={() => setSelectedMember(null)}
          onSelectAnotherMember={(m) => setSelectedMember(m)}
          onUpdateMember={handleUpdateMember}
          isAdminLoggedIn={isAdminLoggedIn}
        />
      )}

      {/* Admin Login Modal */}
      {isAdminLoginModalOpen && (
        <AdminLoginModal
          language={language}
          onClose={() => setIsAdminLoginModalOpen(false)}
          onSuccessLogin={() => {
            handleSwitchUser('maruf');
            setIsAdminLoggedIn(true);
            showToast(isBn ? 'মারুফ হিসেবে লগইন সফল!' : 'Logged in as Maruf!');
          }}
        />
      )}

      {/* Visitor Request / Scanned Document Submission Modal */}
      {isVisitorRequestModalOpen && (
        <VisitorRequestModal
          language={language}
          onClose={() => setIsVisitorRequestModalOpen(false)}
          onSubmitRequest={handleSubmitVisitorRequest}
        />
      )}

      {/* Add New Member Modal */}
      {isAddMemberModalOpen && (
        <AddMemberModal
          language={language}
          onClose={() => setIsAddMemberModalOpen(false)}
          onAddMember={handleAddMember}
        />
      )}

      {/* App Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/80 py-6 mt-12 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            {isBn 
              ? 'মারুফের পরিবার ডিজিটাল ভল্ট ও আইনি এআই সহায়ক © ২০২৬ • ক্লায়েন্ট-সাইড AES-256 এনক্রিপ্টেড' 
              : "Maruf's Family Digital Vault & Legal AI Assistant © 2026 • Client-Side AES-256 Encrypted"}
          </p>
          <div className="flex items-center gap-4 text-[11px] text-slate-500">
            <span>{isBn ? 'ভূমিকা ভিত্তিক এক্সেস কন্ট্রোল (RBAC)' : 'Role-Based Access Control (RBAC)'}</span>
            <span>•</span>
            <span>{isBn ? 'অডিট ট্রেইল সিকিউরিটি লগ সক্রিয়' : 'Audit Trail Active'}</span>
            <span>•</span>
            <span>{isBn ? 'মরহুম মোঃ আব্দুল বারিক ভূঁইয়া এস্টেট' : 'Late Md. Abdul Barek Bhuyan Estate'}</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
